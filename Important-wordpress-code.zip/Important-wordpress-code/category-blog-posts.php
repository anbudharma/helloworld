<?php get_header(); ?>                    
        <div class="blog-holder">
            <div class="container">
                <div class="blog-content">
                    <div class="row">
                        <div class="col-sm-12">
                       
					<?php    $cate = of_get_option('blog_widget');                  
												global $post;    
												$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
												
												$args = array( 'category' => $cate,'posts_per_page' => 4, 'paged' => $paged, 'offset'=> 0, 'orderby'  => 'post_date', 'order'  => 'DESC');												 
												   $cate1 = $args[category];												 										
													$myposts = get_posts( $args ); 
												   $num =count($myposts); ?>    
                                                 <h1><?php echo get_cat_name( $cate1 ); ?></h1>
                       <p><?php echo category_description( $cate1 ); ?></p> <br/>
                        
                        <?php 	   foreach( $myposts as $key => $post ) {  setup_postdata($post);  
						     if($key % 2 == 0){  
						  
						?>
                                <div class="blog-box col-sm-12">
                                    <div class="row">
                                    	<?php
										if (has_post_thumbnail( $post->ID ) ){ 
										$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'tiny-feature' ); 
										?>	
                                        <div class="col-sm-6 col-sm-nopadding">
                                            <div class="blog-img-1">
                                                 <a href="<?php echo get_permalink(); ?>"><img src="<?php echo $image[0];?>" class="img-responsive"  alt="" border="0" /></a>
                                            </div>
                                        </div> 
                                        <?php } ?>                           
                                        <div class="col-sm-6 col-sm-nopadding">
                                            <div class="blog-text">
                                            <h4><?php echo get_the_title(); ?></h4>
                                            <h5>Post by : <?php  echo get_the_author();  ?>    |    Post on : <?php echo get_the_date('M d, Y'); ?>  at <?php echo get_the_time('', $post->ID); ?> </h5>
                                            <p><?php echo get_the_excerpt(); ?></p>
                                            <div class="row">
                                                <div class="col-sm-4">
                                                    <a class="btn btn-blog" href="<?php echo get_permalink(); ?>">LEARN MORE</a>
                                                </div>
                                            
                                                
                                            </div>
                                            </div>
                                        </div>  
                                    </div>
                                </div>
                               <?php }   if($key % 2 == 1){ ?>
								   <div class="blog-box col-sm-12">
                                    <div class="row">
                                    <div class="col-sm-6 col-sm-nopadding">
                                            <div class="blog-text">
                                            <h4><?php echo get_the_title(); ?></h4>
                                            <h5>Post by : <?php  echo get_the_author();  ?>    |    Post on : <?php echo get_the_date('M d, Y'); ?>  at <?php echo get_the_time('', $post->ID); ?> </h5>
                                            <p><?php echo get_the_excerpt(); ?></p>
                                            <div class="row">
                                                <div class="col-sm-4">
                                                    <a class="btn btn-blog" href="<?php echo get_permalink(); ?>">LEARN MORE</a>
                                                </div>
                                            
                                                
                                            </div>
                                            </div>
                                        </div>
                                        
                                    	<?php
										if (has_post_thumbnail( $post->ID ) ){ 
										$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'tiny-feature' ); 
										?>	
                                        <div class="col-sm-6 col-sm-nopadding col<?php echo $i;?>">
                                            <div class="blog-img-1">
                                                 <a href="<?php echo get_permalink(); ?>"><img src="<?php echo $image[0];?>" class="img-responsive"  alt="" border="0" /></a>
                                            </div>
                                        </div> 
                                        <?php } ?>                           
                                          
                                    </div>
                                </div>
							   <?php }
							  } 
							?>
                            <div class="pagination-spl">
                              <nav>
                                  <?php 
                                  if (function_exists("pagination"))
                                  {
                                    pagination($additional_loop->max_num_pages);
                                  }            
                                  ?>
                              </nav>
                          </div>
                        </div>                        
                        
                        
                    </div>

                </div>
                
            </div>
        </div>
 <?php get_footer(); ?>
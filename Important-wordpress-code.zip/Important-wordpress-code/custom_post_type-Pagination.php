
                                    
      <?php /* 
	 Add Function.php
      */      
      
       function leadership( $query ) 
		{
			if ( $query->is_home() && $query->is_main_query() ) 
			{				
			$query->set( 'posts_per_page', 1 );
			}
		}
		add_action( 'pre_get_posts', 'leadership' );        ?>               
                                    
                                    
  <?php
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
$loop = new WP_Query( array(
'post_type' => 'leadership',
'posts_per_page' => 1,
'orderby'=> 'menu_order',
'paged'=>$paged
) ); ?>
<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>


    <div class="doel">
        <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(array('class' => 'featuredimg')); ?></a>
        <img class="logodoel" src="<?php the_field('logo_doelen'); ?>" />
        <h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
        <p><a href="<?php the_permalink(); ?>"><?php the_excerpt(); ?></a></p>
        <a href="" class="doneerlink">Doneer nu</a>
    </div>

<?php endwhile; ?><br class="clear" /> 
<?php

if(function_exists('wp_pagenavi')) 
{
    wp_pagenavi(array(  'query' => $loop) ); 
    wp_reset_postdata(); 
}
?>

                                    
                                <?php query_posts ($query_string . '&cat=4'); ?>

                        <?php global $post;   if(have_posts() ){

                            while( have_posts() ){ the_post(); ?>
  
                                    
                                  
                                                <div class="col-sm-6">
                                                  <div class="leader_ship_inner">
                                                  <?php the_post_thumbnail('leader_image',array('class'=>'img-responsive center-block'));  ?> 
                                                  	
                                                    <h5><?php echo get_the_title(); ?></h5>
                                                    </div>
                                                    <p><?php echo get_the_excerpt(); ?></p>
                                                    <a class="btn read" href="<?php echo get_permalink(); ?>">Read more</a>
                                                 
                                                    
                                                </div>
                                                 <?php  //} ?>
                                                
                                           
                                           
                                           <?php } }?>
                                          
                                        
                                        &nbsp;
                                         &nbsp;
                                         <div class="page_nav pull-right">
                                        <?php 
										 //wp_pagenavi(); 
                                        
                                              if (function_exists("pagination")) {
                                                pagination($additional_loop->max_num_pages);
                                              }           
                                              ?>
                                             </div>
                                </div>
                        </div>
                        	
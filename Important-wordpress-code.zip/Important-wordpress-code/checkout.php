<?php 
/*Template Name:checkout*/ 
get_header();?>
&nbsp;
<div class="container">   
	<div class="row">
	
	<div class="col-sm-7">
	
	 <div class="final_info">     	 
	 <form enctype="multipart/form-data" method="post" class="wpsc_checkout_forms validform">               
	 <?php if($_GET['msg'] == 'error'){?><p style="  background: none repeat scroll 0 0 #F0F0F0; border: 1px solid #CCCCCC; border-radius: 4px 4px 4px 4px; color: #FF0000;font-weight: bold;  margin-bottom: 10px; padding: 14px;">Please Enter Valid Card Details</p><?php }?>
	
				 <table class="wpsc_checkout_table table-2" style="background:none !important;">       
						  <tbody>                   
						   <tr class="">                       
								<td colspan="2" class="wpsc_billing_forms">                   
									 <h3>Pay Invoice PayPal </h3>               
								 </td>                 
							</tr>                    <?php /*?><tr>                        <td>The faster, safer way to pay</td>                        <td><img src="<?php bloginfo('template_url');?>/img/others/pay-pal-pro.jpg" /></td>                    </tr><?php */?>           
						  </tbody>         
				</table>       
					 <table class="wpsc_checkout_table table-1" style="background:none !important;">             
						<tbody>                 
						   <tr class="">                 
								  <td colspan="2" class="wpsc_billing_forms ">               
										   <h3>Your billing/contact details</h3>            
								  </td>  
						  </tr>          
				 
							  <tr>   
								 <td ><label for="name-of-business">Name of Business <span class="asterix">*</span></label></td>   
								 <td><input type="text" name="meta[name_of_business]" value="" title="Enter Name of Business" class="required nob"></td>                   
							 </tr>
							 <tr>                        
								<td ><label for="first-name">First Name <span class="asterix">*</span></label></td>                 
								<td><input type="text" name="meta[first_name]" value="" title="Enter First Name" class="required fname"></td>           
							 </tr>	  
							 <tr>
								 <td><label>Last Name <span class="asterix">*</span> </label></td>                        
								 <td><input type="text" name="meta[last_name]" value="" title="Enter Last Name" class="required lname"></td>                    
							</tr>                    
							<tr>
									 <td ><label for="invoice-number">Invoice Number<span class="asterix">*</span></label></td>                      
									<td><input type="text" name="meta[invoice_number]" value="" title="Enter Invoice Number" class="required ein"></td>        
								</tr>
								 <tr>
									  <td><label>Payment Amount<span class="asterix">*</span> </label></td>                        
									  <td><input type="text" name="meta[amount]" value="" title="Payment Amount" class="required amount"></td>                   
								 </tr>
									  <td><label>Email <span class="asterix">*</span> </label></td>                        
									  <td><input type="text" name="meta[email]" value="" title="Enter Email Address" class="required email lname"></td>                    
								</tr>                    
								<tr>                        
									<td><label>Address <span class="asterix">*</span> </label></td>                        
									<td><textarea cols="40" rows="3" name="meta[address]" title="Enter Address" class="required address"></textarea></td>                    
								</tr>                    
								<tr>                        
									<td><label>City <span class="asterix">*</span> </label></td>                        
									<td><input type="text" name="meta[city]" value="" title="Enter City" class="required city"></td>                    
								</tr>                    
							<tr>                        
								<td><label>State <span class="asterix">*</span></label></td>                       
								 <td><input type="text" name="meta[state]" value="" title="billingstate town" class="required state" ></td>                    
							</tr>                    
							<tr>                        
								<td><label>Postal Code <span class="asterix">*</span> </label></td>                        
								<td><input type="text" name="meta[zip]" value="" title="Enter Postal Code" class="required zip"></td>                    
							</tr>                   
							<tr>                        
								<td><label>Phone <span class="asterix">*</span></label></td>                        
								<td><input type="text" name="meta[phone]" value="" title="Enter Phone Number" class="required phone"></td>                    
							</tr>                                        
							<tr class="">                        
								<td colspan="2" class="wpsc_billing_forms">                        
									<h3>Pay with my Credit Card</h3>                        
								</td>                    
							</tr>                    
							<tr>                        
								<td><label>Card Type <span class="asterix">*</span></label></td>                       
								<td><select name="meta[card_type]" title="Select Card Type " class="required" >                                
									<option value="visa" selected="selected">Visa</option>                               
									 <option value="MasterCard">Master Card</option>                                
									 <option value="AmericanExpress">American Express</option>  
									 <option value="AmericanExpress">Discover</option>                          
									</select>                       
								 </td>                    
							</tr>                    
							<tr>                        
								<td><label>Cardholder Name <span class="asterix">*</span> </label></td>                       
								<td><input type="text" name="meta[cardholder_name]" value="" title="Enter Cardholder Name " class="required"></td>                   
							 </tr>                   
							 <tr>                        
								<td><label>Card Number <span class="asterix">*</span> </label></td>                        
								<td><input type="text" name="meta[cardnumber]" value="" title="Enter Card Number" class="required" ></td>                   
							 </tr>                    
							 <tr>                        
								<td><label>Expiration <small>[ mm / yyyy ] </small><span class="asterix">*</span> </label></td>                        
								<td>                            
								<input type="text" name="meta[expiration_month]" placeholder="mm" size="2" value="" title="Enter Expiration" class="required">                            <input type="text" name="meta[expiration_year]" placeholder="yyyy" size="4" value="" title="Enter Expiration" class="required">                        				                            </td>                    
								</tr>                    
							 <tr>                        
								<td><label>CVV Number<a href="http://www.cvvnumber.com/cvv.html" target="_new" class="blue" style="  color: #4054B5;font-size: 10px;margin-left: 10px;text-decoration: none;" title="Visa®, Mastercard®, and Discover® cardholders:    Turn your card over and look at the signature box. You should see either the entire 16-digit credit card number or    just the last four digits followed by a special 3-digit code. This 3-digit code is your CVV number / Card Security Code.    American Express® cardholders:    Look for the 4-digit code printed on the front of your card just above and to the right of your main credit card number. This 4-digit code is your Card Identification Number (CID). The CID is the four-digit code printed just above the Account Number. ">What is this?</a></label>                        
								</td>                       
								 <td><input type="text" name="meta[card_cvv]" value="" title="CVV Number" class="required" ></td>                    
							</tr> 
							 <tr>
								 <td align="right" valign="top"> <label>Captcha code:</label></td>
								  <td><img src="https://job1one.org/wp-content/themes/jobone/captcha.php?rand=<?php echo rand();?>" id='captchaimg'><br>
									<label for='message'>Enter the code above here :</label>
									<br>
									<input id="captcha_code" name="captcha_code" type="text">
									<br>
									Can't read the image? click <a class="atags" href='javascript: refreshCaptcha();'>here</a> to refresh.
								 </td>
							</tr>
				 </tbody>           
				  </table>           
					 <table class="wpsc_checkout_table table-2" style="background:none !important;">                
						<tr>                   
							 <td colspan="2">                    
								<div class="wpsc_make_purchase">                     
									<span>                           
										<input type="button" class="make_purchase wpsc_buy_button paypal-pay get_start_blue btn" value="Payment">						   
										<input type="hidden" name="submit" value="PayNow" />                    
									 </span>
									  <span class="red paypal-pay-process" style="display:none; padding:0 0 0 115px;">Your Payment is being processed... Please wait...</span>                   			 </div>                  
							  </td>               
						 </tr>            
					 </table>    &nbsp;    
					</form>    
				</div>
			</div>
			 <div class="col-sm-5">
			  <?php if (have_posts()) : ?>
											 <?php while (have_posts()) : the_post();                               		  	
												  the_content('Read the rest of this entry &raquo;'); ?>                                                                      
												 <?php  
												 //comments_template();										 
												 endwhile; 
												  endif; ?> 
			</div>
	 </div>
 </div>
 <?php get_footer(); ?>
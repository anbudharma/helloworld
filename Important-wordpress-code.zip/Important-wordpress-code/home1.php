<?php get_header(); ?>
        <div class="holder">
        	<div class="container">
            	<div class="table-holder">
                	<div class="row">
                    	<div class="col-sm-8">
                       
                        <?php  $time_table = of_get_option('time_table');   $id= $time_table;  $post= get_post($id); ?>
                        	       	<h3><?php echo get_the_title(); ?></h3>
                               <div class="table-responsive"> <p><?php  echo $content = apply_filters( 'the_content',  $post->post_content );   ?></p>  </div>     
                      
                        </div>
                        <div class="col-sm-4">
                        <?php dynamic_sidebar('contact-widget-area'); ?>
                        	
                        </div>
                    </div>
                </div>
                <br/>
                <div class="about-holder">
                	<div class="row">
                    	<div class="col-sm-6">
                        	<div class="about-content">
                            	 <?php echo of_get_option('theme_welcome'); ?>   
                            </div>
                        </div>
                        <div class="col-sm-6">
                        	<h3><?php echo of_get_option('lat_blog'); ?></h3>
                            <br/>
                             <?php   $cate = of_get_option('latest_blog');                  
												global $post;    
												$args = array( 'category' => $cate, 'numberposts' => 3, 'offset'=> 0, 'orderby'  => 'post_date', 'order'  => 'DESC');												 
												    $cate1 = $args[category];			 										
													$myposts = get_posts( $args );
												$num =count($myposts); ?>    
                                                <?php 	   foreach( $myposts as $key => $post ):  setup_postdata($post);  ?>
                                                
                            <div class="blog">
                            	<div class="row">
                                    <div class="col-sm-4">
                                    	<br/>
                                         <?php
                                        if (has_post_thumbnail( $post->ID ) ):
                                          $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' );
                                        ?>
                                         <a href="<?php echo get_permalink(); ?>"><img src="<?php echo $image[0];?>"  alt="test"  class="img-responsive" /></a>
                                         <?php endif; ?>  
                                    </div>
                                    <div class="col-sm-8">
                                        <h5> <a href="<?php echo get_permalink(); ?>"><?php echo get_the_title(); ?></a></h5>
                                        <h6>Posted on <?php echo get_the_date('d M Y'); ?></h6>
                                        <p><?php echo get_the_excerpt(); ?></p>
                                    </div>
                                </div>
                            </div>
                            <br/>
                            <?php endforeach; ?>
                            <a class="btn btn-read" href="<?php echo get_category_link( $cate1 ); ?>">View more Posts</a>                         
                        </div>
                    </div>
                </div>
            </div>
            <br/>
            <div class="our-team text-center">
            	<div class="container">
                	
                     <?php   $cate = of_get_option('our_team');                  
												global $post;    
												$args = array( 'category' => $cate, 'numberposts' => -1, 'offset'=> 0, 'orderby'  => 'post_date', 'order'  => 'DESC');												 
												    $cate1 = $args[category];												 										
													$myposts = get_posts( $args ); 
													
												$num =count($myposts); ?> 
                                                <h3><?php echo get_cat_name( $cate1 ); ?></h3> 
                    <p><?php echo category_description( $cate1 ); ?>    </p>
                    <br/>
                    <div id="carousel-team" class="carousel slide1" data-ride="carousel">
                        <div class="carousel-inner1">
                        <div class="artsliders">
                       
                                 
                                                <?php 	   foreach( $myposts as $key => $post ):  setup_postdata($post);  ?>
                                                
                                     <div class="items">
                                        <div class="team">
                                              <?php
                                        if (has_post_thumbnail( $post->ID ) ):
                                          $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' );
                                        ?>
                                         <img src="<?php echo $image[0];?>"  alt="test"  class="img-responsive" />
                                         <?php endif; ?>  
                                            <?php echo get_the_title(); ?>
                                            <p><?php echo get_the_excerpt(); ?></p>
                                        </div>
                                  </div>
                                    <?php endforeach; ?>
                        </div>
                        </div>                      
                    </div>
                </div>
            </div>
        </div>
 <?php get_footer(); ?>
$(function(){
	$('#wppb-register-user .text-input').addClass('form-control');
	$('#wppb-register-user .submit').addClass('btn btn-more');
		
	$('#loginform .input').addClass('form-control');
	$('#loginform .button-primary').addClass('btn btn-more');
	
	$('#wppb-edit-user .text-input').addClass('form-control');
	$('#wppb-edit-user .submit').addClass('btn btn-more');
	
	$('.wppb-logout-url').addClass('btn btn-more');
	$('.default_field_display-name').addClass('form-control');
	
	$('#wppb-recover-password .submit').addClass('btn btn-more');
	$('#wppb-edit-user').addClass('form-control');
	  
	$('.login .input-text').addClass('form-control');
	
	});

$(".para2").hide();
$(".hides").hide();
$(".hides1").hide();

$("a.reads").click(function(){
	var a=($(this).parent().attr('class'));
	var a="."+a;
	$(a+" .para1").hide("slow");
	$(a+" .para2").slideToggle("slow");
	$(a+" .hides").slideToggle("slow");
	$(a+" .reads").hide("slow");
});
	
$("a.hides").click(function(){
	var a=($(this).parent().attr('class'));
	var a="."+a;
	$(a+" .para2").hide("slow");
	$(a+" .para1").slideToggle("slow");
	$(a+" .reads").slideToggle("slow");
	$(a+" .hides").hide("slow");
});
<?php 
/*
Template Name: Front
*/
get_header();
?>
<div class="holder">
    	<div class="welcome-all">
        	<div class="container">
            	<div class="welcome-content">
                	<div class="row">
                      <?php echo of_get_option('theme_welcome'); ?>                    	
                        <div class="col-sm-3">
                        	<br/> 
                        	 <?php dynamic_sidebar('mnt-client-widget-area'); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="our-tools-all">
        	<div class="container">
            	<div class="popular-heading">
                 <?php  $popular_tools_page = of_get_option('popular_tools_page');   $id= $popular_tools_page;  $post= get_post($id); ?>
            		<h3><?php echo get_the_title(); ?></h3>
                </div>
                <br/>
                <div class="tick-point">
                <?php  echo $content = apply_filters( 'the_content',  $post->post_content );   ?>                	
                </div>
                <br/>
                <br/>
                <br/>
            </div>
        </div>
        <div class="success-all">
        	<div class="container">
            	<div class="success-content text-center">
                	<div class="success-heading">
                    <?php   $cate = of_get_option('popular_tools');                  
                                                  global $post;    
                                                  $args = array( 'category' => $cate, 'numberposts' => -1, 'offset'=> 0, 'orderby'  => 'post_date', 'order'  => 'DESC');												 
                                                      $cate1 = $args[category];												 										
                                                      $myposts = get_posts( $args ); 													
                                                  $num =count($myposts); ?> 
                		<h3><?php echo get_cat_name( $cate1 ); ?></h3>
                    </div>
                    <br/>
                    <br/>
                    <div class="all-icons">
                    	<div id="icon-slide" class="carousels slide" data-ride="carousel" >
                        <div class="carousel-inners">
                        <div class="artsliders">
                                      <?php 	   foreach( $myposts as $key => $post ) {  setup_postdata($post);  ?>
                                          <div class="icon-content">
                                          
                                              <div class="icon">
                                                   <?php   if($getallimages = get_post_meta($post->ID, '_icon_img', true)) {
													foreach($getallimages as $images):?>
													<a href="<?php echo get_permalink(); ?>"><img src=<?php echo $images['image']; ?> class="img-respnsive center-block" /> </a><?php   endforeach; ?><?php } ?>
                                              </div>
                                              <div class="icon-para">
                                                  <h4><?php echo get_the_title(); ?></h4>
                                                  <p><?php echo get_the_excerpt(); ?></p>
                                                  <a href="<?php echo get_permalink(); ?>">Read more + </a>
                                              </div>
                               			   </div>
                                    <?php } ?>  
                          
                       			 </div>
                            </div>                           
                        </div> 
                    </div>
                </div>
            </div>
        </div>
        <div class="latest-news-all">
        	<div class="container">  
            	<div class="news-heading">
                <?php   $cate = of_get_option('latest_news');                  
												global $post;    
												$args = array( 'category' => $cate, 'numberposts' => 2, 'offset'=> 0, 'orderby'  => 'post_date', 'order'  => 'DESC');												 
												    $cate1 = $args[category];												 										
													$myposts = get_posts( $args ); 													
												$num =count($myposts); ?>     
            	<h4><?php echo get_cat_name( $cate1 ); ?></h4>
                </div>
                <div class="news-content">
                	<div class="row">
                                                 <?php 	   foreach( $myposts as $key => $post ) {  setup_postdata($post);  ?>                                            
                                                <div class="col-sm-6">
                                                    <div class="image-text">
                                                        <div class="row">
                                                            <div class="col-sm-5">
                                                                <div class="image">
                                                                   <?php
																if (has_post_thumbnail( $post->ID ) ):
																  $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' );
																?>
																 <a href="<?php echo get_permalink(); ?>"><img src="<?php echo $image[0];?>"  alt="test"  class="img-responsive center-block" /></a>
																 <?php endif; ?>
                                                                </div>
                                                            </div>
                                                            <div class="col-sm-7">
                                                                <div class="text">
                                                                    <h5><?php echo get_the_title(); ?></h5>
                                                                    <p><?php echo get_the_excerpt(); ?></p>
                                                                    <div class="news-button">
                                                                        <a href="<?php echo get_permalink(); ?>" class="btn btn-news"> Read more + </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                          <?php } ?>
                        
                    </div>
                    <br/>
                    <br/>
                </div>
            </div>
        </div>
    </div>
 <?php get_footer(); ?>
   
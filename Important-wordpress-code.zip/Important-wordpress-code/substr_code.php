<?php get_header(); 
$ourareas= stripslashes(get_option('ca_ourareas'));
$bottom_widget= stripslashes(get_option('ca_bottom_widget')); 
$homewidget= stripslashes(get_option('ca_homewidget')); 
$ourservices= stripslashes(get_option('ca_ourservices')); 
$homepage= stripslashes(get_option('ca_homepage')); 
$Testimonial_widget= stripslashes(get_option('ca_Testimonial_widget')); 
$Testimonial= stripslashes(get_option('ca_Testimonial')); 
?>
<div class="holder">
    	<div class="service">
        	<div class="container">
            <div class="row-fluid">
             <?php           global $post;
                               $tmp_post = $post;
                               $args = array( 'category' => $homewidget, 'numberposts' => 3, 'offset'=> 0, 'orderby'  => 'post_date', 'order'  => 'DESC');
                               $myposts = get_posts( $args );
                               foreach( $myposts as $post ) : setup_postdata($post);
                              ?>
                	<div class="span4">
                    	<div class="service-box">
                            <div class="service-thumb">
                                <?php the_post_thumbnail(); ?>
                            </div>
                            <h3><?php echo get_the_title(); ?></h3>
                            <?php the_excerpt(); ?>
                         <?php /*?>   <p><?php $con = get_the_content();
							 $dot = ".";
     $position = stripos ($con, $dot); 
echo  $first_two = substr($con, 0, $position).'.';?>           </p><?php */?>
                            <a href="<?php echo get_permalink(); ?>">LEARN MORE</a>
                        </div>
                    </div>
                 <?php endforeach; wp_reset_query(); ?>
                 </div>   
            
            
            </div>
        </div>
        <div class="about-holder">
        	<div class="container">
            	<div class="about-box">
                    <div class="row-fluid">
                        <div class="span8">
                         <?php       $id=$homepage; $post = get_post($id); 
                            echo "<h2>".get_the_title()."</h2>";
                             the_post_thumbnail(); 
                             $content = apply_filters('the_content', $post->post_content);   echo substr($content,0,610); ?>
                            <a href="<?php echo get_permalink(); ?>" class="black-read">READ MORE</a>
                       </div>
                        <div class="span4">
                        	<div class="form">
                          	  <?php dynamic_sidebar('quick-contact-widget-area');?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="design-holder">
        	<div class="container">
            	<div class="row-fluid">
                 <?php           global $post;
                               $tmp_post = $post;
                               $args = array( 'category' => $bottom_widget, 'numberposts' => 2, 'offset'=> 0, 'orderby'  => 'post_date', 'order'  => 'DESC');
                               $myposts = get_posts( $args );
                               foreach( $myposts as $post ) : setup_postdata($post);
                              ?>
                              <div class="span4">
                    	<div class="row-fluid">
                       
                        	<div class="span4">
                            	<div class="design-thumb">
                            		  <?php the_post_thumbnail(); ?>
                                </div>
                            </div>
                            <div class="span8">
                            	<h5><?php echo get_the_title(); ?></h5>
                                <?php $content = get_the_content();
								  $trimmed_content = wp_trim_words( $content, 20 ); ?>
  								<p><?php echo $trimmed_content; ?></p>
                                <?php /*?><p><?php  $contents = apply_filters('get_the_content', $post->post_content); 
								 $dot = ".";
								   $positions = stripos ($contents, $dot); 
                                  echo  $firsts = substr($contents, 0, $positions).'.';
								 ?></p><?php */?>
                                <a href="<?php echo get_permalink(); ?>" class="more">LEARN MORE</a>
                            </div>
                        </div>
                    </div>
                              <?php endforeach; ?>
                    <div class="span4">
                        <div class="clients">
                        <div class="carousel">
                                <ul class="slides">
                          <?php           global $post;
                               $tmp_post = $post;
                               $args = array( 'category' => $Testimonial_widget, 'numberposts' => -1, 'offset'=> 0, 'orderby'  => 'post_date', 'order'  => 'DESC');
                               $myposts = get_posts( $args );
                               foreach( $myposts as $post ) : setup_postdata($post);
                              ?><li>
                                        <h5 class="red"><?php echo $Testimonial; ?></h5>
                                        <p class="italic"><?php $cons = get_the_content(); 
										 $dot = ".";
										    $position = stripos ($cons, $dot); //find first dot position
echo  $first = substr($cons, 0, $position).'.';
										//echo substr($con,0,120); ?></p>
                                        <h6>By <?php  $com = get_post_custom_values('testi_authors'); echo $com[0];  ?></h6>
                                    </li>
                              <?php endforeach; ?>
                              </ul>
                        </div>
					</div>
                </div>
            </div>
        </div>
        <div class="logo-clint">
        	<div class="container">
            	<ul class="inline">
                <?php           global $post;
                        $tmp_post = $post;
                        $args = array( 'post_type' => 'partner', 'numberposts' => 8, 'offset'=> 0, 'orderby'  => 'post_date', 'order'  => 'DESC');
                        $myposts = get_posts( $args );
                       foreach( $myposts as $post ):  setup_postdata($post);  ?>
                        <li><a href="#">  <?php
							  if (has_post_thumbnail( $post->ID ) ):
                              $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' );
                        ?>
                              <img src="<?php echo $image[0];?>"  alt="banners" /><?php endif; ?></a></li>
                  <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>
</div>
 <?php get_footer(); ?>
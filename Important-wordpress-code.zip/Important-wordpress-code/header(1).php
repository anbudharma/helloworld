<?php
session_start();
if( isset( $_POST['submit']) ){				
// Set sandbox (test mode) to true/false.
$sandbox = FALSE; 
if($_POST['meta']['name_of_business']=='') 
{
 echo '<h6>' . "* Enter Name Of Business"  . '</h6>';
}

if($_POST['meta']['first_name']=='') 
{
 echo '<h6>' . "* Enter your First Name"  . '</h6>';
}
 if($_POST['meta']['last_name']=='') 
{
	 echo '<h6>' . "* Enter your Last Name"  . '</h6>';
}
 if($_POST['meta']['invoice_number']=='') 
{
		 echo '<h6>' . "* Enter Invoice Number"  . '</h6>';
}
 if($_POST['meta']['amount']=='') 
{
		 echo '<h6>' . "* Enter Payment Amount"  . '</h6>';
}
 if($_POST['meta']['email']=='') 
{
		 echo '<h6>' . "* Enter your Email"  . '</h6>';
}
if($_POST['meta']['address']=='') 
{
		 echo '<h6>' . "* Enter your Address"  . '</h6>';
}
if($_POST['meta']['city']=='') 
{
		 echo '<h6>' . "* Enter your City"  . '</h6>';
}
if($_POST['meta']['state']=='') 
{
		 echo '<h6>' . "* Enter your State"  . '</h6>';
}
if($_POST['meta']['zip']=='') 
{
		 echo '<h6>' . "* Enter Postal Code"  . '</h6>';
}
if($_POST['meta']['phone']=='') 
{
		 echo '<h6>' . "* Enter Phone"  . '</h6>';
}

 if($_POST['meta']['card_type']=='') 
{
		 echo '<h6>' . "* Enter Card Type"  . '</h6>';
}
if($_POST['meta']['cardholder_name']=='') 
{
		 echo '<h6>' . "* Enter Cardholder Name"  . '</h6>';
}
if($_POST['meta']['cardnumber']=='') 
{
		 echo '<h6>' . "* Enter Card Number"  . '</h6>';
}
if($_POST['meta']['expiration_year']=='') 
{
		 echo '<h6>' . "* Enter Expiration"  . '</h6>';
}

if(empty($_SESSION['captcha_code'] ) || strcasecmp($_SESSION['captcha_code'], $_POST['captcha_code']) != 0)
	{  

		echo '<h6>' ."* The Captcha code does not match!". '</h6>';	
	}	
	if(($_POST['meta']['invoice_number']!='') || ($_POST['meta']['name_of_business']!='') || ($_POST['meta']['first_name']!='') || ($_POST['meta']['last_name']!='') ||($_POST['meta']['email']!='')||($_POST['meta']['address']!='') ||($_POST['meta']['city']!='') ||($_POST['meta']['zip']!='') ||($_POST['meta']['amount']!='') ||($_POST['meta']['card_type']!='') ||  ($_POST['meta']['cardholder_name']!='') ||($_POST['meta']['cardnumber']!='') ||($_POST['meta']['expiration_year']!='') || (!empty($_SESSION['captcha_code'] )) || (strcasecmp($_SESSION['captcha_code'], $_POST['captcha_code']) == 0 ) ){

// Set PayPal API version and credentials.
$api_version = '204.0';
$api_endpoint = 'https://api-3t.paypal.com/nvp';
$api_username = 'wrobinson_api1.job1one.org';
$api_password = 'TTCT6YNVUE42Y8MW';
$api_signature = 'Ajf4qNjjXUPL3w8O0p4gLAfpkN4rAN3hWNRn9oxvPkHjyGGSA1Ho83aq';

$request_params = array
(
'METHOD' => 'DoDirectPayment', 
'USER' => $api_username, 
'PWD' => $api_password, 
'SIGNATURE' => $api_signature, 
'VERSION' => $api_version, 
'PAYMENTACTION' => 'Sale', 					
'IPADDRESS' => $_SERVER['REMOTE_ADDR'],
'CREDITCARDTYPE' => $_POST['meta']['card_type'], 
'ACCT' => $_POST['meta']['cardnumber'], 						
'EXPDATE' => $_POST['meta']['expiration_month'].$_POST['meta']['expiration_year'], 			
'CVV2' => $_POST['meta']['card_cvv'], 
'FIRSTNAME' => $_POST['meta']['first_name'], 
'LASTNAME' => $_POST['meta']['last_name'], 
'STREET' => $_POST['meta']['address'], 
'CITY' => $_POST['meta']['city'], 
'STATE' => $_POST['meta']['state'], 					
'COUNTRYCODE' => 'USA', 
'ZIP' => $_POST['meta']['zip'], 
'AMT' => $_POST['meta']['amount'], 
'OrderTotal' => $_POST['meta']['amount'], 
'CURRENCYCODE' => 'USD', 
'DESC' => 'Job1one' 
);

$nvp_string = '';

foreach($request_params as $var=>$val){
$nvp_string .= '&'.$var.'='.urlencode($val);	
}

// Send NVP string to PayPal and store response
$curl = curl_init();
curl_setopt($curl, CURLOPT_VERBOSE, 1);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($curl, CURLOPT_TIMEOUT, 30);
curl_setopt($curl, CURLOPT_URL, $api_endpoint);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl, CURLOPT_POSTFIELDS, $nvp_string);
$result = curl_exec($curl);

curl_close($curl);


// Parse the API response
function NVPToArray($NVPString)
{
$proArray = array();
while(strlen($NVPString)){
// name
$keypos= strpos($NVPString,'=');
$keyval = substr($NVPString,0,$keypos);
// value
$valuepos = strpos($NVPString,'&') ? strpos($NVPString,'&'): strlen($NVPString);
$valval = substr($NVPString,$keypos+1,$valuepos-$keypos-1);
// decoding the respose
$proArray[$keyval] = urldecode($valval);
$NVPString = substr($NVPString,$valuepos+1,strlen($NVPString));
}
return $proArray;

}
$result_array = NVPToArray($result);
print_r($result_array[L_LONGMESSAGE0]);
print_r($result_array[ACK]);
if($result_array[ACK]!='Failure'){
$nobs = $_POST['meta']['name_of_business'];
$fnames = $_POST['meta']['first_name'];
$lnames = $_POST['meta']['last_name'];
$amounts = $_POST['meta']['amount'];
$inumbers = $_POST['meta']['invoice_number'];
$emails = $_POST['meta']['email'];
$addres = $_POST['meta']['address'];
$citys = $_POST['meta']['city'];
$states = $_POST['meta']['state'];
$zips = $_POST['meta']['zip'];
$phones = $_POST['meta']['phone'];
$cardstypes = $_POST['meta']['card_type'];
$cardholdname = $_POST['meta']['cardholder_name'];
$cardnumbers = $_POST['meta']['cardnumber'];
$expirationyr = $_POST['meta']['expiration_year'];

$my_post = array(
   	   'post_title'    =>   $nobs,
       'post_type'    => 'pay_invoice',
       'meta_input' => array('name_of_business'=>$nobs,'first_name'=> $fnames,'last_name'=> $lnames,'invoice_number'=> $inumbers,'payment_amount'=> $amounts,'payment_amount'=> $amounts,'email_s'=> $emails,'addresss'=> $addres,'city_s'=> $citys,'states'=> $states,'postal_scode'=> $zips,'phonse'=> $phones,'card_stype'=> $cardstypes,'cardholder_sname'=> $cardholdname,'card_number_s'=> $cardnumbers,'expiration_syear'=> $expirationyr),
	   'post_status' => 'draft'
);

// Insert the post into the database.
wp_insert_post( $my_post );
}

}
exit();
}
?>
<!DOCTYPE html>
<html lang="en-us">
	<head>
		<meta charset="utf-8">
		<!--<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">-->

		<title><?php wp_title(); ?></title>
		<meta name="author" content="">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

		<!-- CSS -->
        <link rel="stylesheet" type="text/css" media="screen" href="<?php echo get_template_directory_uri(); ?>/css/bootstrap.css">
        <link rel="stylesheet" type="text/css" media="screen" href="<?php echo get_template_directory_uri(); ?>/css/bootstrap-theme.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,300italic,700,800' rel='stylesheet' type='text/css'>
        <link rel="stylesheet" type="text/css" media="screen" href="<?php echo get_template_directory_uri(); ?>/style.css">

		<!-- FAVICONS -->
		<link rel="shortcut icon" href="<?php echo get_template_directory_uri(); ?>/img/favicon/favicon.png" type="image/png">
		<link rel="icon" href="<?php echo get_template_directory_uri(); ?>/img/favicon/favicon.png" type="image/png">
        <?php if(of_get_option('theme_pay_invoice')!="") { ?>
        <style type="text/css">
		
		 .btn-req  { font-size:0px; border:0px solid #ccc;
		 background:rgba(0, 0, 0, 0) url("<?php echo of_get_option('theme_pay_invoice'); ?>") no-repeat scroll 0px -2px;	  }
			  .btn-default:hover, .btn-default:focus {  background-color: #fff !important;  background-position: 0 -2px;  color: #fff !important;}
		</style>
        
        <?php } ?>
        <?php wp_head(); ?>        
	</head>

    <body>
    	<header>
        	<div class="header-top">
            	<div class="container">
                	<div class="row">
                    	<div class="col-sm-5 col-md-2 col-lg-2">
                        	<div class="top-contact-links">
                            	<ul class="list-inline">
                                	<li><a href="tel:<?php echo of_get_option('contact_phone'); ?>"><img src="<?php echo get_template_directory_uri(); ?>/img/others/phone.png" alt="Img" /> <?php echo of_get_option('contact_phone'); ?></a></li>
                                    <li><a href="mailto:<?php echo of_get_option('contact_email'); ?>"><img src="<?php echo get_template_directory_uri(); ?>/img/others/email.png" alt="Img" /> <?php echo of_get_option('contact_email'); ?></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-sm-3 col-md-2 col-lg-2">
							<div class="invoi">
                        	   <?php dynamic_sidebar('pay_button'); ?>
						  	 </div>
                        </div>
                        <div class="col-sm-3 col-md-2 col-lg-2">
                        	<?php dynamic_sidebar('donate_button'); ?>
                        </div>
                        <div class="col-sm-4 col-md-2 col-lg-2">
                        	<?php dynamic_sidebar('request_button'); ?>
                        </div>
                        <div class="col-sm-4 col-md-2 col-lg-2">
                        	<?php dynamic_sidebar('job_button'); ?>
                        </div>
                        <div class="col-sm-4 col-md-2 col-lg-2">
                        	<div class="top-share-links">
                            	<ul class="list-inline">
                                	<?php if( of_get_option('facebook')!="" ) { ?><li><a target="_blank" href="<?php echo of_get_option('facebook'); ?>"><i class="fa fa-facebook"></i></a></li><?php } ?>
                                    <?php if( of_get_option('twitter')!="" ) { ?><li><a target="_blank" href="<?php echo of_get_option('twitter'); ?>"><i class="fa fa-twitter"></i></a></li><?php } ?>
                                    <?php if( of_get_option('instagram')!="" ) { ?><li><a target="_blank" href="<?php echo of_get_option('instagram'); ?>"><i class="fa fa-instagram"></i></a></li><?php } ?>
                                    <?php if( of_get_option('youtube')!="" ) { ?><li><a target="_blank" href="<?php echo of_get_option('youtube'); ?>"><i class="fa fa-youtube"></i></a></li><?php } ?>
                                    <?php if( of_get_option('linkedin')!="" ) { ?><li><a target="_blank" href="<?php echo of_get_option('linkedin'); ?>"><i class="fa fa-linkedin"></i></a></li><?php } ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="header-bottom">
            	<div class="container">
                	<div class="row">
                    	<div class="col-sm-2">
                        	<div class="logo text-center">
                            	<a href="<?php bloginfo('home'); ?>">
                                	<img src="<?php echo of_get_option('logo'); ?>" alt="Img" class="img-responsive" />
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-10">
                        	<div class="mainmenu">
                                <nav class="navbar top-navbar" role="navigation">
                                    <div class="navbar-header">
                                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#main-menu">
                                            <span class="sr-only">Toggle navigation</span>
                                            <span class="icon-bar"></span>
                                            <span class="icon-bar"></span>
                                            <span class="icon-bar"></span>
                                        </button>
                                    </div>                           
                                    <div class="collapse navbar-collapse" id="main-menu">
                                    	<?php $args = array('theme_location' => 'main', 'menu_class' => 'nav navbar-nav navbar-right', 'container' => false, 'link_before' => '', 'link_after' =>'', 'walker' => new My_Walker_Nav_Menu()); wp_nav_menu($args); ?>
                                    </div>
                                </nav>
                            </div>
                        </div>
					</div>
				</div>
			</div>
        </header>
<?php get_header(); ?>   
 <div class="holder">
        	<div class="container">
            	<div class="welcome-holder text-center">
                <?php echo of_get_option('theme_welcome'); ?>                	
                </div>
                <div class="product-holder">
                	<h3><?php echo of_get_option('theme_ourproducts'); ?></h3>
                      <div class="artsliders">
                    <?php /*?><div id="carousel-pro" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner"><?php */?>
                         <?php      $args = array( 'post_type' => 'product',  'posts_per_page' => 8, 'meta_key' => '_featured',   'meta_value' => 'yes',    'orderby' =>'date','order' => 'DESC' );
          
								  $loop = new WP_Query( $args );
								  //print_r($loop);
								  $key = 0;
								   $num = $loop->post_count;
								  while ( $loop->have_posts() ) : 								  
								  $loop->the_post(); global $product; ?>     
                                  
                            <div class="items">
                                        <div class="box">
                                            <div class="img-thumb">
                                                  <?php  if (has_post_thumbnail( $loop->post->ID )) the_post_thumbnail($loop->post->ID, array ('class' => 'img-responsive' )); else echo '<img style="width:100%" src="'.woocommerce_placeholder_img_src().'" />'; ?>
								
                                            </div>
                                            <div class="content text-center">
                                                <p><?php echo get_the_title(); ?> </p>
                                                <h6><?php if ( $price_html = $product->get_price_html() ) : ?>
                                       <?php echo $price_html; ?> 	<?php endif; ?></h6>
                                            </div>
                                            <div class="button text-center">
                                               <?php $pro_id = get_the_id(); ?>
                                                <?php echo do_shortcode('[add_to_cart id="'.$pro_id.'"]'); ?>  
                                             <?php /*?>   <a href="#" class="btn btn-cart">Add To Cart</a><?php */?>
                                            </div>
                                            <?php /*?><div class="kg">
                                            	<h5>100 kg</h5>
                                            </div><?php */?>
                                        </div>
                            </div>
                             <?php endwhile;  wp_reset_query(); ?>
                            </div>
                           
            </div>
            <div class="testimonials text-center">
            	<div class="container">
                	<div class="title">
                    	<h3><?php echo of_get_option('theme_clienttesti'); ?></h3>
                        <div id="carousel-test" class="carousel slide" data-ride="carousel">
                            <div class="carousel-inner">
                             <?php
                            global $post; 
                            $args = array( 'numberposts' => -1, 'post_type' => 'testimonials' );
                            $myposts = get_posts( $args );
                            foreach( $myposts as $key=>$post ) { setup_postdata($post); ?>                            
                                 <div class="item <?php if($key == 0){?> active<?php }?>">                                
                                    <div class="test-content">
                                        <p><?php echo get_the_content(); ?></p>
                                        <h6><?php echo get_the_title(); ?></h6>
                                    </div>
                                </div>
                                <?php } ?>
                            </div>
                            <div class="carousel-nav">
                            <ol class="carousel-indicators">
									 <?php
                                  global $post; $i = 0;
                                  $args = array( 'numberposts' =>-1, 'post_type' => 'testimonials' );
                                  $myposts = get_posts( $args );
                                  foreach( $myposts as $post ) { setup_postdata($post); ?>
                                          <li data-target="#carousel-test" data-slide-to="<?php echo $i; ?>" class="<?php if($i == 0){?> active <?php  }?>"></li>
                                      <?php $i++; } ?>
                                      </ol>
                                
                           </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> 
</div>
<?php get_footer(); ?>     
    
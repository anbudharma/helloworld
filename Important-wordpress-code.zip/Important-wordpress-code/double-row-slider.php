<?php get_header(); ?>  
  <div class="holder">
        	<div class="welcome-holder text-center">
            		<div class="container">
                      <div rel="stretchLeft" class="animation">
                           <?php echo of_get_option('theme_welcome'); ?>
                       </div>
                  </div>
            </div>
            <div class="box-holder">
              <div rel="stretchLeft" class="animation">
            	<div class="container">                
                  	<div class="row">
                    <?php   $cate = of_get_option('home_widget');                  
												global $post;    
												$args = array( 'category' => $cate, 'numberposts' => 3, 'offset'=> 0, 'orderby'  => 'post_date', 'order'  => 'DESC');												 
												    $cate1 = $args[category];												 										
													$myposts = get_posts( $args );
												$num =count($myposts); ?>
                                    <?php		 $i=0;  foreach( $myposts as $key => $post ) {  setup_postdata($post);  ?>
                    	<div class="col-sm-4 text-center">
                        	  <?php
							  if (has_post_thumbnail( $post->ID ) ):
								$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' );
							  ?>
							  <a href="<?php echo get_permalink(); ?>"><img src="<?php echo $image[0];?>"  alt="icons" class="img-responsive" /></a>
							   <?php endif; ?> 
                            <h4><?php echo get_the_title(); ?></h4>
                            <p><?php echo get_the_excerpt(); ?></p>
                        </div>
                       <?php } ?>                       
                    </div>
                  </div>                	
                </div>
            </div>
            <div class="bottom-holder">
            	<div class="container">
                	 <div rel="stretchRight" class="animation">
                     	<div class="row">
                    	<div class="col-sm-4">
                        	<h5><?php echo of_get_option('past_events')?></h5>
                            <?php   $cate = of_get_option('events_category');                  
												global $post;    
												$args = array( 'category' => $cate, 'numberposts' => 2, 'offset'=> 0, 'orderby'  => 'post_date', 'order'  => 'DESC');												 
												    $cate1 = $args[category];												 										
													$myposts = get_posts( $args );
												$num =count($myposts); ?>
                                                <?php		 $i=0;  foreach( $myposts as $key => $post ) {  setup_postdata($post);  ?>
                                                  <div class="event-box">
                                                      <div class="row">
                                                          <div class="col-sm-4">
                                                              <br/>
                                                               <?php
																if (has_post_thumbnail( $post->ID ) ):
																  $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' );
																?>
																 <img src="<?php echo $image[0];?>"  alt="banners" width="100%" class="img-responsive" />
																 <?php endif; ?> 
                                                          </div>
                                                          <div class="col-sm-8">
                                                              <h6><?php echo get_the_title(); ?></h6>
                                                              <p><?php echo get_the_excerpt(); ?></p>
                                                          </div>
                                                      </div>
                                                  </div>
                                                  <br/>
                         					   <?php } ?>                           
                        </div>
                        <div class="col-sm-4">
                        <?php dynamic_sidebar('new-event-widget-area'); ?> 
                        </div>                     
                        <div class="col-sm-4">
                        	<h5><?php echo of_get_option('board_reviews'); ?></h5>
                            <div id="carousel-review" class="carousel slide" data-ride="carousel">
                                <div class="carousel-inner">
                                 <?php   $cate = of_get_option('board_category');                  
												global $post;    
												$args = array( 'category' => $cate, 'numberposts' => -1, 'offset'=> 0, 'orderby'  => 'post_date', 'order'  => 'DESC');												 
												    $cate1 = $args[category];												 										
													$myposts = get_posts( $args );
													$num =count($myposts); ?>
                                                	<?php		 $i=0;  foreach( $myposts as $key => $post ) {  setup_postdata($post);  ?>
                                                 
                                                    
                                                  <?php if( $key%2==0 ) {?> <div class="item <?php if( $key==0 ) {?> active<?php } ?>"> <?php } ?>
                                                      <div class="event-box">
                                                          <div class="row">
                                                              <div class="col-sm-4">
                                                                  <br/>
                                                                 <?php
																  if (has_post_thumbnail( $post->ID ) ):
																	$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' );
																  ?>
																  <a href="<?php echo get_permalink(); ?>"><img src="<?php echo $image[0];?>"  alt="icons" class="img-responsive" /></a>
																   <?php endif; ?> 
                                                              </div>
                                                              <div class="col-sm-8">
                                                                  <h6><a href="<?php echo get_permalink(); ?>"><?php echo get_the_title(); ?></a></h6>
                                                                  <p><?php echo get_the_excerpt(); ?></p>
                                                              </div>
                                                          </div>
                                                      </div>
                                                      <br/>
                                                      
                                                   <?php if($key%2==1 || $key+1==$num) { ?></div><?php } } ?>                                                 
                                </div>
                                <div class="carousel-nav">
                                    <a class="carousel-nav-prev" href="#carousel-review" data-slide="prev">Prev</a>
                                    <a class="carousel-nav-next" href="#carousel-review" data-slide="next">Nexty</a>
                                </div>
                            </div>
                        </div>
                    </div>
                     </div>
                	
                </div>
            </div>
        </div>         
        <br/>
<?php get_footer(); ?>
      
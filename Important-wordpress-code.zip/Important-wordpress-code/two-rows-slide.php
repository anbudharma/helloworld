<?php get_header(); ?>
	<section class="holder">
		<div class="container">
			<div class="row">
				<div class="col-sm-8">
					<div class="about"><?php  $charlie = of_get_option('charlie');   $id= $charlie;  $post= get_post($id); ?>
						<h1><?php echo get_the_title(); ?></h1>
						<?php the_excerpt(); ?>
						
					</div>
					<div class="testimonial">
						<h1><?php echo of_get_option('what_say'); ?></h1>
						<ul class="bxslider">
						<?php
					global $post; 
					$args = array( 'numberposts' => -1, 'post_type' => 'testimonial' );	
					$posts = get_posts(  $args  );
					$count = count($posts);
					$tot_slide = $count / 2;
					if( ($count % 2) != 0 ){ $tot_slide++; }
					 ?>	
					<?php for( $i = 1; $i <= $tot_slide; $i++)
					{?>
							<li>
							<?php 	$start = ( $i - 1 ) * 2;
								$end = $start + 2;
								
								$last = 1;
								
								for( $j = $start; $j < $end; $j++)
								{
									if( ! empty($posts[$j]) )
										{
											$post = $posts[$j];
											setup_postdata( $post ); ?>
											<div class="testimonial-set test<?php echo $j+1;?>">
												<p>"<?php echo get_the_content(); ?>"</p>
												<span>- <?php echo get_the_title(); ?></span>
											</div>										
										<?php if(($j+2)%2==0) { ?><hr/>	 <?php } ?>
									 <?php $last++; 								 
								 		} 
								}		?>
							</li>
				<?php } ?>
						</ul>
					</div>
				</div>
				<div class="col-sm-4">
					<aside class="sidebar">
					 <?php   $cate = of_get_option('sidebox');                  
												global $post;    
												$args = array( 'category' => $cate, 'numberposts' => 6);										 
												    $cate1 = $args[category];												 										
													$myposts = get_posts( $args );
												$num =count($myposts); ?>
							 <?php		 $i=0;  foreach( $myposts as $key => $post ) {  setup_postdata($post);  ?>
                                                					
						<div class="side<?php echo $key+1; ?>">
						  <h3><a href="<?php echo get_permalink(); ?>"><?php echo get_the_title(); ?></a></h3>
						  <?php 								
							$image = get_field('thum_img');
								// vars
								$url = $image['url'];							

								// thumbnail
								$size = 'side_image';
								$thumb = $image['sizes'][ $size ];
								$width = $image['sizes'][ $size . '-width' ];
								$height = $image['sizes'][ $size . '-height' ]; ?>
								<img src="<?php echo $thumb; ?>" alt="post" class="img-responsive center-block"/>	
						</div>
						<?php } ?>
					</aside>
				</div>
			</div>
		</div>
	</section>
<?php get_footer(); ?>	


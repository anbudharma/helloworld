<?php  get_header(); 
$photgraphy= stripslashes(get_option('ca_photgraphy')); 
$photo= stripslashes(get_option('ca_photo'));
$sortby= stripslashes(get_option('ca_sortby'));
?>  
 <div class="holder">
        	<div class="top-holder">
                <div class="container">
                    <div class="title text-center">
                        <h4><?php echo $photgraphy; ?></h4>
                    </div>
                    <div class="row">
                      <?php
	     $taxonomy1 = array('taxonomy' => 'wpsc_product_category','field' => 'slug','terms' => 'photgraphy' );
		 $args = array('post_type' => 'wpsc-product','posts_per_page' => 3,'orderby' => 'date','order' => 'DESC','post_status' => 'publish','tax_query' => array($taxonomy1));
		$posts = get_posts(  $args  );
		$count = count($posts);
		 for( $i = 0; $i < $count; $i++)		 
		 {			 
								$post = $posts[$i];
								setup_postdata( $post );
				?>
                                <div class="col-lg-4">
									<div class="box">
									 <?php the_post_thumbnail('prod_img'); ?>
										<div class="overlay text-center">
											<a href="<?php echo get_permalink(); ?>"><h4><?php echo get_the_title(); ?></h4></a>
										</div>
									</div>
                       		 </div>
                                  
        <?php }?>
                    </div>
                </div>
            </div>
            <div class="bottom-holder">
            	<div class="container">
                	<div class="row">
                    	<div class="col-lg-4">
                        	<h4><?php echo $photo; ?></h4>
                        </div>
                        <div class="col-lg-3 col-lg-offset-5">
                        	<div class="row">
                            	<div class="col-lg-5">
                                	<h4><?php echo $sortby; ?></h4>
                                </div>
                                <div class="col-lg-7">                                
                                <form name="choose_prod" class="" method="get" action="<?php bloginfo("url") ?>">
            					<input type="hidden" name="s" value="product" />
          						  <select class="bycat form-control" name="wpcat" onchange="this.form.submit();">
         							  <?php /*?> <option value="">by Category</option><?php */?>
								<?php
										$wpec_product_categories = get_terms( 'wpsc_product_category', 'hide_empty=0&parent=0');
										foreach($wpec_product_categories as $wpec_categories){
										$wpec_term_id = $wpec_categories->term_id;
										$wpec_term_name = $wpec_categories->name;
										$wpec_term_slug = $wpec_categories->slug;
										?>
										<option value="<?php echo $wpec_term_slug;?>" <?php if($wpec_term_slug==$_GET['wpsc_product_category']) { ?> selected="selected" <?php } ?>><?php echo  $wpec_term_name;?></option>
										<?php }?>
										</select>
									   </form>                   
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="photo-holder">
                    	<div id="carousel-gallery" class="carousel slide" data-ride="carousel">
                    		<div class="carousel-inner">
                             <?php
	    // $taxonomy1 = array('taxonomy' => 'wpsc_product_category','field' => 'slug' );
		$args = array('post_type' => 'wpsc-product','posts_per_page' => -1,'orderby' => 'date','order' => 'DESC','post_status' => 'publish','category__not_in' => array(3,4));
		$posts = get_posts(  $args  );
		$count = count($posts);
		$tot_slide = $count / 8;
		if( ($count % 8) != 0 ){ $tot_slide++; }
		for( $i = 1; $i <= $tot_slide; $i++){
								$start = ( $i - 1 ) * 8;
								$end = $start + 8;
								$last = 1;								
								?>
                                <div class="item <?php if($i==1):?>active<?php endif; ?>">
									 <div class="widget">                                   
											<?php 
											for( $j = $start; $j < $end; $j++){
											if( ! empty($posts[$j]) ){
											$post = $posts[$j];
											$post = $posts[$j];
											setup_postdata( $post );								
											if($j%4==0){ ?>  <div class="row">  <?php } ?>
											  <div class="col-lg-3">
													<div class="photo">
														<a href="<?php echo get_permalink(); ?>" class="carts"><img src="<?php bloginfo("template_url"); ?>/img/icons/carts.png" alt="carts"/></a>
															 <span class="pro_title"><?php echo get_the_title(); ?></span>
															  <?php the_post_thumbnail('photo_img',array('class'=>'img-responsive')); ?>
													</div>
												</div>                                         
											<?php $last++; ?>  <?php } ?>
												  <?php if($j%4==3){ ?>  </div> <?php } ?>								
											<?php }?>
									</div> 
                                 </div>   <?php }?>  
									<div class="carousel-nav">
									   <ol class="carousel-indicators">
											<?php for( $i = 0; $i<($tot_slide-1);$i++){?>
											<li data-target="#carousel-gallery" data-slide-to="<?php echo $i; ?>" <?php if($i==0) { echo 'class="active"'; } ?>></li>
											<?php } ?>  
										  
										  </ol>
									</div>
						   </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> 
 <?php get_footer(); ?>    
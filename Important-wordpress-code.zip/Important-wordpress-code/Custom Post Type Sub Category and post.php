	<?php
/* Custom Post Type Sub Category and Post Display*/
$taxonomy = 'corporate_category';
$terms = get_terms($taxonomy); // Get all terms of a taxonomy

if ( $terms && !is_wp_error( $terms ) ) :
?>
    <ul>
        <?php foreach ( $terms as $key => $term ) { 
		 $resudate= $term->slug;	
		?>
            <li><a href="<?php echo get_term_link($term->slug, $taxonomy); ?>"><?php echo $term->name; ?></a>
			
				<?php
																		global $post; $i = 1;
																		$args = array( 'numberposts' =>-1, 'post_type' => 'corporate_service','corporate_category'=> $resudate );
																		$myposts = get_posts( $args );																		
																		foreach( $myposts as $key => $post ) { setup_postdata($post); 
																		//echo $key.'</br>';	
																		?>
																		<h4><?php echo get_the_title(); ?></h4>
																		
																		<?php } ?>
			</li>
			
        <?php } ?>
    </ul>
<?php endif;
	
/* Custom Post Type Sub Category and Post Display*/
?>
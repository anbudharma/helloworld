<?php 
/*
Template Name: Testimonials 
*/
get_header();?>   
<div class="holder">
            	<div class="about-holder about-holder-inner">                	
                		<div class="about_box_main breads_main">
                        	<div class="container">                           
                            	<div class="about_box_main_inner">
                                  <div class="row">
                                      <div class="breads">
                                            <?php if(function_exists('bcn_display'))
                                                {
                                                    bcn_display();
                                                }?>
                                       </div>
                                       <h3><?php post_type_archive_title(); ?></h3>
                                       
                                       
                                   <?php if (have_posts()) : ?>
			<?php $paged = (get_query_var('paged')) ? get_query_var('paged') : 1; query_posts("post_type=testimonials&posts_per_page=2&caller_get_posts=1&paged='. $paged .'"); ?>
		<?php while (have_posts()) : the_post(); ?>

											<div class="box">
                                                    <div class="row">
                                                       <div class="col-sm-12">                                                            
                                                         <div class="blog_cont"><?php the_content();?></div>
                                                                      <h4><?php the_title();?></h4>                                                         
                                                        </div>                                                        
                                                	    </div>                                                    
                                                    </div>
		<?php endwhile; ?>
			<?php if(function_exists('wp_pagenavi')) { wp_pagenavi(); } ?>
		<?php else : endif; ?>




	<?php
										//$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;	
										
									//	$args = array('posts_per_page' => 2,  'paged' => $paged, 'post_type' => 'testimonials' );			
									//	$myposts = get_posts( $args );			
										//foreach( $myposts as $key=>$post ) { setup_postdata($post); ?>                            
												<?php /*?><div class="box">
                                                         <div class="row">
                                                        <div class="col-sm-12">                                                            
                                                          <div class="blog_cont"><?php the_content();?></div>
                                                                      <h4><?php the_title();?></h4>                                                         
                                                        </div>                                                        
                                                    </div>                                                    
                                                    </div><?php */?>
                                                <?php // } ?>
                                            </div>
                                            <div class="list">
                                                     <div class="list_inner">
									   <?php 
                                              if (function_exists("pagination")) {
                                      pagination($additional_loop->max_num_pages);
                                  }            
                                              ?></div>
                <?php /*?><img src="<?php bloginfo("template_url");?>/images/list.png" width="271" height="24" alt="post" /><?php */?>
            </div>
			</div>            
        </div>
        </div>
        </div>
        </div>
<?php get_footer();?>
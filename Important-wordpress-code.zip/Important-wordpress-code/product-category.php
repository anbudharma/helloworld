<?php get_header(); ?>

<div class="main_holder">

              <div class="container">

            	<div class="text-center store_holder">

                	<h3>OUR STORE</h3>                   

                </div>

                	<div class="Box_holder">

                    	<div class="row">

                        <?php $wcatTerms = get_terms('product_cat', array('hide_empty' => 0, 'order' => 'DESC',  'parent' => 12, )); 

					       foreach($wcatTerms as $wcatTerm) : 

        $wthumbnail_id = get_woocommerce_term_meta( $wcatTerm->term_id, 'thumbnail_id', true );

        $wimage = wp_get_attachment_url( $wthumbnail_id );

    ?>

                        	<div class="col-sm-3">

                            	<div class="box1">	

                                	<div class="box_img">

                                      <a href="<?php echo get_term_link( $wcatTerm->slug, $wcatTerm->taxonomy ); ?>">

                                       <?php if($wimage!=""):?><img src="<?php echo $wimage?>" class="img-responsive"><?php endif;?></a>

                                    </div>

                                    <div class="box_content">

                                    	<h4><?php echo $wcatTerm->name; ?></h4>

                                        <p><?php  echo $wcatTerm->description?></p>

                                        <a class="btn views" href="<?php echo get_term_link( $wcatTerm->slug, $wcatTerm->taxonomy ); ?>">view all collections</a>

                                    </div>

                                </div> 

                               </div>

                            <?php endforeach; ?> 

                                	                           	

                            </div>

                            

                            

                        </div>                       

                    </div>

                    	    <div class="our_news_holder">	

                            	<div class="container">

                                	<div class="row">                                	

                                        <div class="col-sm-6">

                                            <div class="authenti">

                                              <h2>Authentication</h2>                                        	

                                                <div class="authenti_content">

                                                    <p>Find the Mounted Memories hologram on your guaranteed authentic product and enter its number into the field below. </p>

                                                  <img src="<?php echo get_template_directory_uri(); ?>/img/icons/bottom-logo.png" alt="bottom-logo" class="img-responsive"/>

                                                 

                        <form class="form-horizontal" role="search" method="get" id="searchform" action="<?php echo esc_url( home_url( '/'  ) ); ?>">

                      <input class="form-control" type="text" value="<?php echo get_search_query(); ?>" name="s" id="s" placeholder="<?php _e( 'Enter Hologram Number', 'woocommerce' ); ?>" />

                      <input type="submit" class="btn authent" id="searchsubmit" value="<?php echo esc_attr__( 'Authenticate' ); ?>" />

                      <input type="hidden" name="post_type" value="product1" />

                      </form>

        

                                                </div>

                                                

                                            </div>

                                        </div>

                                            <div class="col-sm-6">

                                                <div class="latest_news">

                                                  <h2><?php echo of_get_option('latest_news');  ?></h2>

                                                     <?php   $cate = of_get_option('newscat');                  

												global $post;    

												$args = array( 'category' => $cate, 'numberposts' => 2, 'offset'=> 0, 'orderby'  => 'post_date', 'order'  => 'DESC');												 

												  $cate1 = $args[category];												

													$myposts = get_posts( $args ); 

												$num =count($myposts);

											$i=1;	

									   foreach( $myposts as $key => $post ):  setup_postdata($post);  ?>

                                       

                                                  <div class="news_box<?php echo $i;?>">

                                                  		<div class="row">

                                                    	<div class="col-sm-5">

                                                           <div class="news_img">	

																	  <?php

                                                              if (has_post_thumbnail( $post->ID ) ):

                                                                $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' );

                                                              ?>

                                                               <img src="<?php echo $image[0];?>"  alt="banners"  class="img-responsive" />

                                                               <?php endif; ?>

                                                              </div>

                                                        </div>

                                                        <div class="col-sm-7">

                                                        	<div class="news_content">	

                                                            	<span><?php echo get_the_date('M d, Y'); ?></span>

                                                        		<p><b><?php echo get_the_title(); ?></b><br/>  

<?php echo get_the_excerpt(); ?><a href="<?php echo get_permalink(); ?>">Read More</a></p>

																

                                                            </div>

                                                        </div>

                                                    </div>

                                                  </div>

                                                  

                                                  <?php $i++; endforeach;   

												// Get the URL of this category

												$category_link = get_category_link( $cate1 );

											?>

							  <a class="btn views_news" href="<?php echo esc_url( $category_link ); ?>">view all News</a>

                                                </div>

                                            </div>

                                </div>

                                </div>

                                </div>

                                

                                <div class="parner-holder">

                                	<div class="container">

                                    	<div class="row">

                                        	<div class="partner">

                                            	<?php dynamic_sidebar('bottom-widget-area'); ?>

                                            </div>

                                        </div>

                                    </div>

                                </div>

 </div>

 <?php get_footer(); ?>
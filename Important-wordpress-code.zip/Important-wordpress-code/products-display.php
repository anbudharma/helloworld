 <?php get_header(); ?>
        <div class="holder">
        	<div class="container">
            	<br/>
                  <?php echo of_get_option('theme_welcome'); ?>            	
                <br/>
                <hr/>
                <div class="service-holder text-center">
                	<div class="container">
                    	<h3><?php echo of_get_option('theme_ourservices'); ?></h3>
                        <br/>
                        <div class="row">
                         <?php      $args = array( 'post_type' => 'product',  'posts_per_page' => 8, 'product_cat' => 'our-services',    'orderby' =>'date','order' => 'DESC' );
          
								  $loop = new WP_Query( $args );
								  //print_r($loop);
								  $key = 0;
								   $num = $loop->post_count;
								  while ( $loop->have_posts() ) : 								  
								  $loop->the_post(); global $product; ?> 
                        	<div class="col-sm-3">
                            	<div class="box">
                                	 <?php  if (has_post_thumbnail( $loop->post->ID )) the_post_thumbnail($loop->post->ID, array ('class' => 'img-responsive' )); else echo '<img style="width:100%" src="'.woocommerce_placeholder_img_src().'" />'; ?>
								 <br/>
                                    <h4><?php echo get_the_title(); ?> </h4>
                                  <br/>
                                    <p><?php echo get_the_content(); ?></p>
                                 <br/>
                                     <?php $pro_id = get_the_id();									 
									  echo do_shortcode('[add_to_cart id="'.$pro_id.'"]'); ?>  
                                   <?php /*?> <a href="#">Add to Cart</a><?php */?>
                                </div>
                            </div>
                           <?php endwhile;  wp_reset_query(); ?>                             
                        </div>
                    </div>
                </div>
                <br/>
                <hr/>
                <div class="bottom-holder">
                	<div class="container">
                    	<div class="row">
                        	<div class="col-sm-6">
                            	<div class="blog">
                                <h3><?php echo of_get_option('theme_latest_blog'); ?></h3>
                                <?php   $cate = of_get_option('lastest_blog');                  
												global $post;    
												$args = array( 'category' => $cate, 'numberposts' => 2, 'offset'=> 0, 'orderby'  => 'post_date', 'order'  => 'DESC');												 
												   $cate1 = $args[category];												 										
													$myposts = get_posts( $args ); 
													$num =count($myposts); 
											   foreach( $myposts as $key => $post ):  setup_postdata($post);  ?>
                                	<div class="box">                                        
                                        <div class="row">
                                            <div class="col-sm-3">
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/icons/blog-1.png" alt="post" class="img-responsive" />
                                            </div>
                                            <div class="col-sm-9">
                                                <h5><?php echo get_the_title(); ?></h5>
                                                <p><?php echo get_the_excerpt(); ?></p>
                                                <a href="<?php echo get_permalink(); ?>">Read more</a>
                                            </div>
                                        </div>
                                    </div>
                                    <hr/>
                                    <?php endforeach; ?>                                                                     
                                </div>
                            </div>
                            <div class="col-sm-6">
                            	<h3><?php  echo $cate = of_get_option('theme_clienttesti'); ?></h3>
                                <div class="row">                                
                               <?php
                            global $post; 
                            $args = array( 'numberposts' => 1, 'post_type' => 'testimonials','offset'=> 0, 'orderby'  => 'post_date', 'order'  => 'ASC' );
                            $myposts = get_posts( $args );
                            foreach( $myposts as $key=>$post ) { setup_postdata($post); ?>     
                            <div class="col-sm-3">
									 <?php
                                        if (has_post_thumbnail( $post->ID ) ):
                                          $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' );
                                        ?>
                                         <img src="<?php echo $image[0];?>"  alt="test"  class="img-responsive" />
                                         <?php endif; ?>  
                            </div>
                                    <div class="col-sm-9">
                                    	<?php the_content(); ?>
                                    </div>
                                 	 <?php } ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> 
        <br/>
 <?php get_footer(); ?>
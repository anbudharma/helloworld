<?php
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<title><?php
	global $page, $paged;
	wp_title( '|', true, 'right' );
	bloginfo( 'name' );
	// Add the blog description for the home/front page.
	$site_description = get_bloginfo( 'description', 'display' );
	if ( $site_description && ( is_home() || is_front_page() ) )
		echo " | $site_description";
	// Add a page number if necessary:
	if ( $paged >= 2 || $page >= 2 )
		echo ' | ' . sprintf( __( 'Page %s', 'twentyten' ), max( $paged, $page ) );
	?></title>
<link rel="profile" href="http://gmpg.org/xfn/11" />
<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
<?php
	/* We add some JavaScript to pages with the comment form
	 * to support sites with threaded comments (when in use).
	 */
if ( is_singular() && get_option( 'thread_comments' ) )
	wp_enqueue_script( 'comment-reply' );
	/* Always have wp_head() just before the closing </head>
	 * tag of your theme, or you will break many plugins, which
	 * generally use this hook to add elements to <head> such
	 * as styles, scripts, and meta tags.
	 */
	wp_head();
?>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
 	<meta name="generator" content="Wordpress" />
<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/css/style.css" />	
		<link rel="profile" href="http://gmpg.org/xfn/11" />
		<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/rokbox-style.css" type="text/css" />
			<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/rokbox-style-ie6.css" type="text/css" />
		<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/rokbox-style-ie7.css" type="text/css" />
		<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/rokbox-style-ie8.css" type="text/css" />
 		<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/template.css" type="text/css" />
  		<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/style2.css" type="text/css" />
 		<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/typography.css" type="text/css" />
 		<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/extras.css" type="text/css" />
 		<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/rokmoomenu.css" type="text/css" />
 		<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/rokstories.css" type="text/css" />
 		<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/wp.css" type="text/css" />
		<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/followme_style.css" type="text/css" />
 		<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/css_style.css" type="text/css" media="screen" />
  		<style type="text/css">
			body { min-width:979px;}
			div.wrapper { margin: 0 auto; width: 979px;padding:0;}
			#leftcol { width:210px;padding:0;float:left;}
			#rightcol { width:260px;padding:0;}
			#main-body { width:699px;padding:0;float:left;}
			#maincol { width:654px;padding:0;float:right;}
			#inset-block-left { width:0px;padding:0;}
			#inset-block-right { width:0px;padding:0;}
			#maincontent-block { margin-right:0px;margin-left:0px;}
  		</style>
  		<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/mootools.js"></script>
  			<?php /*?><script type="text/javascript">var rokboxPath = "http://www.yourstoragecenter.com/wp-content/themes/rt_affinity_child/js/rokbox/";</script><?php */?>
  			<?php /*?><script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/rokbox.js"></script>
  			<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/rokbox-config.js"></script>
 		<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/rokfonts.js"></script>
 		<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/rokdate.js"></script>
 		<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/rokutils.js"></script>
		<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/rokutils.inputs.js"></script>
 		<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/rokmoomenu.js"></script><?php */?>
 		<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/mootools.bgiframe.js"></script>
 		<?php /*?><script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/roktabs/roktabs.js"></script>
 		<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/rokstories.js"></script><?php */?>
<link href="<?php bloginfo('template_url'); ?>/css/default.css" rel="stylesheet" type="text/css" />
    <script src="<?php bloginfo('template_url'); ?>/js/jquery-1.2.6.pack.js" type="text/javascript"></script>
    <script src="<?php bloginfo('template_url'); ?>/js/jquery.flow.1.1.min.js" type="text/javascript"></script>  
<script type="text/javascript">
    $(function() {
        $("div#controller").jFlow({
            slides: "#slides",
            width: "900px",
            height: "200px"
        });
    });
    </script>
    
    
 		<?php /*?><script type="text/javascript">var RokStoriesImage = {}, RokStoriesLinks = {};</script>
 		<script type="text/javascript">
 			window.addEvent('domready', function() {
				var modules = ['side-mod','module','moduletable'];
	 			var header = ['h3'];
	 			RokBuildSpans(modules, header);
 			});
		InputsExclusion.push('.content_vote','#login-module')
			var AffinitySettings = {};
 			AffinitySettings.horizontal = {ghost: 1, ghostOpacity: 0.5, radius: 16};
		AffinitySettings.vertical = {ghost: 1, ghostOpacity: 0.6, radius: 20};
 			AffinitySettings.modules = {ghost: 1, ghostOpacity: 0.6, radius: 16};
		window.addEvent('domready', function() {
 			   	new Rokmoomenu($E('ul.menutop '), {
   			  		bgiframe: false,
  			 		delay: 500,
  			 		verhor: true,
    					animate: {
     						props: ['height'],
    	 					opts: {
    	 						duration: 500,
   	 						fps: 100,
    	 						transition: Fx.Transitions.Quad.easeOut
    	 					}
    	 				},
    	 				bg: {
    		 				enabled: true,
    		 				overEffect: {
   		 					duration: 500,
    		 					transition: Fx.Transitions.Sine.easeOut
    		 				},
    			 			outEffect: {
   			 				duration: 600,
   	 				transition: Fx.Transitions.Sine.easeOut
  		 				}
    	 				},
    	 				submenus: {
    	 					enabled: true,
  		 				opacity: 0.9,
    		 				overEffect: {
    		 					duration: 50,
    		 					transition: Fx.Transitions.Expo.easeOut
    		 				},
   	 					outEffect: {
    	 						duration: 600,
   	 						transition: Fx.Transitions.Sine.easeIn
		    	 					},
    	 					offsets: {
    	 						top: 3,
    	 						right: 1,
	  	 						bottom: 0,
    	 						left: 1
     						}
    					}
     				});
   			});
 		</script>
<?php */?>
<link rel='stylesheet' id='slideshow-gallery-css'  href='<?php bloginfo('template_url'); ?>/css/gallery_css.css' type='text/css' media='screen' />
<script type='text/javascript' src='<?php bloginfo('template_url'); ?>/js/jquery.js'></script>
<script type='text/javascript' src='<?php bloginfo('template_url'); ?>/js/jquery1.js'></script>
<?php /*?><link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php bloginfo('template_url'); ?>/xml/xmlprc.xml" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php bloginfo('template_url'); ?>/xml/xmlprc.xml" /> <?php */?>
<?php /*?><link rel='index' title='Your Storage Center' href='http://www.yourstoragecenter.com' /><?php */?>
<meta name="generator" content="WordPress 3.0.4" />
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/ald-openbrwindow.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/bubble.js"></script>
<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/css/css_style1.css" />
        <script type="text/javascript">
        var tb_pathToImage = "<?php bloginfo('template_url'); ?>/images/loadingAnimation.gif";
		var tb_closeImage = "<?php bloginfo('template_url'); ?>/images/tb-close.png";
		</script> 
<script type="text/javascript">
    window.addEvent('domready', function() {
	var select = $('variation_chooser'), preview = $('variation_preview'), next = $('variation_chooser_next'), prev = $('variation_chooser_prev');
	if (select && preview && prev && next) {
		select.addEvent('change', function(e) {
			new Event(e).stop();
			selectImage(select.selectedIndex);
		});
		prev.addEvent('click', function() {
			var index = select.selectedIndex;
			if (index - 1 < 0) index = select.options.length - 1;
			else index -= 1;
			select.selectedIndex = index;
			selectImage(index);
		});
		next.addEvent('click', function() {
			var index = select.selectedIndex;
			if (index + 1 >= select.options.length) index = 0;
			else index += 1;
			select.selectedIndex = index;
			selectImage(index);
		});
		
		var asset;
		var selectImage = function(index) {
			preview.setStyle('background', 'url(<?php bloginfo('template_url'); ?>/images/loading.gif) center center no-repeat');
			asset = new Asset.image('<?php bloginfo('template_url'); ?>/images/ss_' + select.options[index].value + '.jpg', {
				onload: function() { 
					if (index == select.selectedIndex) preview.setStyle('background-image', 'url(' + this.src + ')');
				}
			});
		};
		
		selectImage(select.selectedIndex);
	};
});
</script>
<?php /*?><script type="text/javascript">
  			RokStoriesImage['rokstories-3'] = [];	
			RokStoriesLinks['rokstories-3'] = [];
	  		
   			RokStoriesImage['rokstories-3'].push('<?php bloginfo('template_url'); ?>/images/CastleRockRok.jpg');
	  			   			
			RokStoriesLinks['rokstories-3'].push('?page_id=6');
 			  		
   			RokStoriesImage['rokstories-3'].push('<?php bloginfo('template_url'); ?>/images/80109Rok.jpg');
   			  			   			
			RokStoriesLinks['rokstories-3'].push('?page_id=6');
			 			  		
			RokStoriesImage['rokstories-3'].push('<?php bloginfo('template_url'); ?>/images/AustinBluffsRok.jpg');
  			   			
			RokStoriesLinks['rokstories-3'].push('?page_id=12');
  			  		
			RokStoriesImage['rokstories-3'].push('<?php bloginfo('template_url'); ?>/images/FtCarsonRok.jpg');
  			   			
			RokStoriesLinks['rokstories-3'].push('?page_id=15');
			  		
   			RokStoriesImage['rokstories-3'].push('<?php bloginfo('template_url'); ?>/images/AAAPlatteRok.jpg');
  			   			
			RokStoriesLinks['rokstories-3'].push('?page_id=6');
	
			window.addEvent('domready', function() {
				new RokStories('rokstories-3', {
					'id': 3,
 					'startElement': 0,
					'thumbsOpacity': 1,
					'mousetype': 'click',
					'autorun': 1,
					'delay': 4500,
					'startWidth': 'auto',
					'layout': 'layout2',
					'linkedImgs': true,
					'showThumbs': 0,
					'fixedThumb': 1,
					'thumbLeftOffsets': {x: -40, y: -100},
					'thumbRightOffsets': {x: -30, y: -100}
				});
			});
			
		</script>
		
		<script type="text/javascript">  var _gaq = _gaq || []; _gaq.push(['_setAccount', 'UA-21049546-1']); _gaq.push(['_trackPageview']); (function() { var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true; ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js'; var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s); })(); </script><?php */?>
		<script type="text/javascript">
        var tb_pathToImage = "<?php bloginfo('template_url'); ?>/images/loadingAnimation.gif";
		var tb_closeImage = "<?php bloginfo('template_url'); ?>/images/tb-close.png";
		</script>
</head>
<body <?php body_class(); ?>>
		<div id="top-bar">
			<div class="wrapper">
				<div class="top-bar-padding">
					<div class="topbar-strip">
						<div class="date-block">
							<span class="date1"><?php echo date('l jS F Y'); ?></span>
						</div>
					<div class="follow-me">
						
						<?php wp_nav_menu( array( 'container_class' => 'menu-header', 'theme_location' => 'secondary' ) ); ?>
			
						
						<A HREF="http://www.youtube.com"><IMG SRC="<?php bloginfo('template_url');?>/images/youtubelargetopicon.png" border="0" align="right"></A><A HREF="http://twitter.com/wycostorage"><IMG SRC="<?php echo bloginfo('template_url');?>/images/twitterlargetopicon.png" border="0" align="right"></A><A HREF="http://www.facebook.com/pages/WYCO-Self-Storage/286684939028"><IMG SRC="<?php echo bloginfo('template_url');?>/images/facebooklargetopicon.png" border="0" align="right"></A></div>
				</div>
		</div>
			</div>
		</div>
<a style="border-bottom: medium none;" href="#" onClick="showFollowMe()" id="FollowMeTabRightLg"><img border="0" src="<?php  bloginfo('template_url');?>/images/rightlg.gif"></a>
<div style="visibility:hidden; height: 578px; width: 1024px;" id="FollowMeBubbleBG"></div>
<div style="visibility: hidden; border-bottom: medium none;" id="FollowMeBubble">
<a style="border-bottom: medium none;" href="#" onClick="showFollowMe()" id="FollowMeTabRightLg"><img border="0" src="<?php  bloginfo('template_url');?>/images/rightlg.gif"></a>
<div style="background-image: url(&quot;<?php  bloginfo('template_url');?>/images/followme_top.gif&quot;); width: 329px; height: 60px; float: left; display: block; border-bottom: medium none;" class="top">
<a style="border-bottom: medium none;" href="#" onClick="hideFollowMe()" id="close"><img border="0" src="<?php  bloginfo('template_url');?>/images/close.png"> </a>
<!--><a id="grab" target="_blank" title="grab this" href="http://www.ignitesocialmedia.com/tools/follow-me/"><span>grab this</span></a>--></div>
<div style="background-image: url(&quot;<?php  bloginfo('template_url');?>/images/followme_mid.gif&quot;); width: 329px; background-repeat: repeat-y; float: left;" class="mid">
<div id="stretch">
<span><a rel="me" href="https://customer.ministoragepayments.com/PreleaseWizard.aspx?7317" target="_blank" title="AAA Platte"><img width="32px" border="0" alt="AAA Platte" src="<?php  bloginfo('template_url');?>/images/avatar.jpg"> AAA Platte</a></span>
<span><a rel="me" href="https://customer.ministoragepayments.com/PreleaseWizard.aspx?7301" target="_blank" title="Aurora"><img width="32px" border="0" alt="Aurora" src="<?php  bloginfo('template_url');?>/images/avatar.jpg"> Aurora</a></span>
<span><a rel="me" href="https://customer.ministoragepayments.com/PreleaseWizard.aspx?3898" target="_blank" title="Castle Rock"><img width="32px" border="0" alt="Castle Rock" src="<?php  bloginfo('template_url');?>/images/avatar.jpg"> Castle Rock</a></span>
<span><a rel="me" href="https://customer.ministoragepayments.com/PreleaseWizard.aspx?5198" target="_blank" title="Austin Bluffs"><img width="32px" border="0" alt="Austin Bluffs" src="<?php  bloginfo('template_url');?>/images/avatar.jpg"> Austin Bluffs</a></span>
<span><a rel="me" href="https://customer.ministoragepayments.com/PreleaseWizard.aspx?7347" target="_blank" title="Ft Carson Army Post"><img width="32px" border="0" alt="Ft Carson Army Post" src="<?php  bloginfo('template_url');?>/images/avatar.jpg"> Ft Carson Army Post</a></span>
</div></div>
<div style="background-image: url(&quot;<?php  bloginfo('template_url');?>/images/followme_bottom.gif&quot;); height: 34px; width: 329px; clear: both; float: left;" class="bottom">
<a href="http://www.ignitesocialmedia.com/tools/follow-me/" style="border-bottom: medium none;" title="grab this" target="_blank" id="grab"><span>grab this</span></a>
</div>
<div style="width: 329px; clear: both; float: left;" class="grab"><a href="http://www.ignitesocialmedia.com/tools/follow-me/" style="border-bottom: medium none;"><img src="<?php  bloginfo('template_url');?>/images/followme_grab.gif"></a></div>
</div>
</div>
		<!--End Top Bar-->
		<!--Begin Header-->
		<div id="header">
			<div id="header-overlay">
				<div class="wrapper">
					<!-- Begin Logo -->
				<div id="logo">
				<?php
					// Check if this is a post or page, if it has a thumbnail, and if it's a big one
					if ( is_singular() && current_theme_supports( 'post-thumbnails' ) &&
							has_post_thumbnail( $post->ID ) &&
							( /* $src, $width, $height */ $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'post-thumbnail' ) ) &&
							$image[1] >= HEADER_IMAGE_WIDTH ) :
						// Houston, we have a new header image!
						echo get_the_post_thumbnail( $post->ID );
					elseif ( get_header_image() ) : ?>
						<img src="<?php header_image(); ?>" width="<?php echo HEADER_IMAGE_WIDTH; ?>" height="<?php echo HEADER_IMAGE_HEIGHT; ?>" alt="" />
					<?php endif; ?>
		
					<?php /*?><a href="http://www.yourstoragecenter.com/" id="logo" class="png"></a><?php */?>
					</div>
					<!-- End Logo -->
				</div>
			</div>
		</div>
			<!--End Header-->
		<div id="page-bg"><div id="page-bg2">
			<!-- Begin Wrapper -->			
			<div class="wrapper">
				
				<!--Begin Horizontal Menu-->
				<div id="horiz-menu" class="moomenu">
					<div id="horiz-menu2">
						<div id="horiz-menu3">
<div id="access" role="navigation">
			  <?php /*  Allow screen readers / text browsers to skip the navigation menu and get right to the good stuff */ ?>
				<div class="skip-link screen-reader-text"><a href="#content" title="<?php esc_attr_e( 'Skip to content', 'twentyten' ); ?>"><?php _e( 'Skip to content', 'twentyten' ); ?></a></div>
				<?php /* Our navigation menu.  If one isn't filled out, wp_nav_menu falls back to wp_page_menu.  The menu assiged to the primary position is the one used.  If none is assigned, the menu with the lowest ID is used.  */ ?>
				<?php wp_nav_menu( array( 'container_class' => 'menu-header', 'theme_location' => 'primary' ) ); ?>
			</div><!-- #access -->
						<div class="clr"></div>
						</div>
					</div>
				</div>
				<!--End Horizontal Menu-->
				
				<!-- Begin Main Content Column -->
				<div id="vertical-sort">
					<!-- Begin Section Row 1 -->
					<div id="widget-rokstories-3" class="widget widget_rokstories"><div id="section-row1" class="section-row"><div id="showcase-surround"><div id="showcase" class="png"><div id="showcase2" class="png"><div id="showcase3" class="png"><div class="showcase-inner"><div id="showmodules" class="spacer"><div class="block full" style="width: 959px;"><div class="module-light"><div id="row1-block1" class="row"><div class="body-surround-top"><div class="body-surround-top2"><div class="body-surround-top3"></div></div></div><div class="body-surround"><div class="body-surround2"><div class="body-surround3"><div class="flush"><div class="moduletable">		
		 		
	<div id="wrap">
    <div id="controller" class="hidden" >
	<?php 
	 query_posts( 'cat=7' );
								  while (have_posts()) : the_post(); ?>
        <span class="jFlowControl">No</span>
      <?php 
	  endwhile;
	  wp_reset_query();
	  ?>  
    </div>
    <div id="prevNext" style="float:left; margin-top:40px;width:253px;margin-left:4px;">
	<div id="leftnav" style="float:left;">
        <img src="<?php  bloginfo('template_url');?>/images/left_normal.png" alt="Previous Tab" class="jFlowPrev" /></div>
<div id="rightnav" style="float:right;"><img src="<?php  bloginfo('template_url');?>/images/right_normal.png" alt="Next Tab" class="jFlowNext" /></div>
    </div></div>
    
    <div id="slides">
<?php
/*$bloginfo = get_bloginfo('url');
 
$querylist = mysql_query("select a.gid, a.name, a.path, b.pid, b.description, b.alttext, b.galleryid, b.filename, b.sortorder, b.alttext from wp_ngg_gallery a, wp_ngg_pictures b where a.gid=1 and b.galleryid=a.gid order by b.sortorder");
*/
  query_posts( 'cat=7' );
								  while (have_posts()) : the_post();
								  if (has_post_thumbnail( get_the_ID() )) : ?>
 <?php $image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'single-post-thumbnail' ); 
 //while ($pictures = mysql_fetch_array($querylist)) {
?>
	    <div id="main">
        <div class="img" ><?php /*?><img src="<?php echo $bloginfo.'/'.$pictures['path'].'/'.$pictures['filename'];?>" alt="" width="160" height="164"/><?php */?> <img src="<?php echo $image[0]; ?>" width="203" height="135"  style=" margin-left: 49px;    margin-top: 31px;"/> </div>
		<div class="title" style="line-height:20px;" ><?php the_title();/*?><p>This is photo number one. Neato! This is photo number one. Neato! This is photo number one. Neato! This is photo number one. Neato! This is photo number one. Neato!</p><?php */?>
		</div>
		<div class="text"><?php the_excerpt();/*?><p>This is photo number one. Neato! This is photo number one. Neato! This is photo number one. Neato! This is photo number one. Neato! This is photo number one. Neato!</p><?php */?>
		</div>
		<div class="readmore"><a href="<?php echo get_permalink(get_the_ID());?>"><img src="<?php  bloginfo('template_url');?>/images/readmore.jpg" style="border:none;" alt="Read More"></a></div>
		</div>
	
<?php endif;  endwhile;  	wp_reset_query();	//} ?>
		
		
	    
</div><!-- end wrap -->
</div></div></div></div></div><div class="body-surround-bottom"><div class="body-surround-bottom2"><div class="body-surround-bottom3"></div></div></div></div></div></div></div></div></div></div></div></div></div></div>
					<!-- End Section Row 1 -->
					<!-- Begin Section Row 2 -->
					<!-- End Section Row 2 -->
					<!-- Begin Section Row 3 -->
					<div id="section-row3" class="section-row">
						<div id="section-row3-inner">
							<div id="main-body-surround" class="spacer">
								<div id="main-body" class="spacing">
									<div class="module-light">
										<div class="body-surround-top">
											<div class="body-surround-top2">
												<div class="body-surround-top3"></div>
											</div>
										</div>
										<!-- Begin Main Body Column -->
										<div class="body-surround">
											<div class="body-surround2">
												<div class="body-surround3">
													<div id="main-content">
														<div id="maincol2">
			  												<div class="maincol-padding">
			  													
			  													<!-- Begin Breadcrumbs -->
																
																<div id="breadcrumbs">
			  														<div id="breadcrumbs2">
			  															<div id="breadcrumbs3">
																			<a href="" id="breadcrumbs-home"></a>
																			<?php
if(function_exists('bcn_display'))
{
    bcn_display();
}
?>
</div>
																		</div>
																	</div>
																
			  													
																<div class="bodycontent">
<div class="mainbody-surround">
<div id="maincontent-block">
<div class="blog">
<div class="leading">
<div class="">
<div class="article-rel-wrapper"></div>
</div>
																<!-- End Breadcrumbs -->
<div class="mainbody-tl">
</div>
<div class="mainbody-tr">
</div>
															
<div class="mainbody-bl">
</div>
<div class="mainbody-br">
</div>
</div>
</div>
</div>

<?php get_header(); ?>
<div class="holder">
        	<div class="welcome-holder text-center">
            	<div class="container">
                <?php echo of_get_option('theme_welcome'); ?> 
                 </div>
            </div>
            <div class="service-holder text-center">
            	<div class="container">  <?php   $cate = of_get_option('video_marketing');                  
												global $post;    
												$args = array( 'category' => $cate, 'numberposts' => 4, 'offset'=> 0, 'orderby'  => 'post_date', 'order'  => 'DESC');												 
												    $cate1 = $args[category];												 										
													$myposts = get_posts( $args );
												$num =count($myposts); ?>
                	<h4><?php echo get_cat_name( $cate1 ); ?></h4>
                    <br/>
                    <div class="row">
								<?php		 $i=0;  foreach( $myposts as $key => $post ) {  setup_postdata($post);  ?>
                    	<div class="col-sm-3">
                        	<div class="box">
                            	<div class="icon">
                                 <a href="<?php echo get_permalink(); ?>"> <?php $com = get_post_meta($post->ID, '_Icons_titles', true); echo $com; ?></a>
                                    <h5><a href="<?php echo get_permalink(); ?>"><?php echo get_the_title(); ?></a></h5>
                                    <div class="list">
                                    	<?php the_content(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
		<footer>	
		<div class="footer-main">		
			<div class="container">
				<ul class="list-inline">
					<li><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/img/others/icon1.png" class="img-responsive" alt="icon1" /></a></li>
					<li><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/img/others/icon2.png" class="img-responsive" alt="icon2" /></a></li>
					<li><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/img/others/icon3.png" class="img-responsive" alt="icon3" /></a></li>
					<li><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/img/others/icon4.png" class="img-responsive" alt="icon4" /></a></li>
					<li><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/img/others/icon5.png" class="img-responsive" alt="icon5" /></a></li>
					<li><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/img/others/icon6.png" class="img-responsive" alt="icon6" /></a></li>
					<li><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/img/others/icon7.png" class="img-responsive" alt="icon7" /></a></li>
					<li><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/img/others/icon8.png" class="img-responsive" alt="icon8" /></a></li>
					<li><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/img/others/icon9.png" class="img-responsive" alt="icon9" /></a></li>
				</ul>
			</div>				
		</div>
	</footer>
 <?php get_footer(); ?>
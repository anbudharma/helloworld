<?php 
/*
Template Name: View Talent
*/
get_header(); ?>
<div class="holder">
    <div class="blog-holder">
        <div class="head-sub">
            <div class="container">
             <?php if (have_posts()) : ?>
                         		 <?php while (have_posts()) : the_post(); ?>
                <h2><?php echo get_the_title();  ?></h2>
               <?php
			   endwhile; 
			  endif;
			   ?>
            </div>
            	<div class="container"> 
                                <div class="about_box_main_inner">  
                                                                                
                                        <?php $parent_id = 11; // The ID of the parent category
                                          $rows = get_categories("include=$parent_id");
                                          $cat_name = $rows[0]->name;
                                          $rows = get_categories("child_of=$parent_id&hide_empty=0");
										  
										   $breakdiv = count($rows);
                                          echo "<h2>Subcategories of $cat_name</h2>";
                                          foreach ($rows as $key=>$row) {											  
											    if($key  == 0  || $key%3==0  ){ ?>  <div class="row"> <?php } ?> 
                                               <div class="col-sm-4">  <?php  
														  z_taxonomy_image_url($row->term_id);?>
														 <div class="crop">
														    <img class="img-responsive" src="<?php echo z_taxonomy_image_url($row->term_id); ?>">
														  </div>
														  <h4><?php echo  $row->name; ?></h4>
														  <p><?php echo  $row->description; ?></p>
                                                          <a class="btn-blue btn" href="<?php echo get_category_link( $row ); ?>">View All</a>
                                              </div> 
											 <?php  if($key % 3 == 2 ){ ?></div><br/><?php } }    ?>  
                                       		 
                                   </div>
                                    
      		 			</div> 
   				 </div> 
   		</div>
	</div>
</div> 
 <?php get_footer(); ?>
 

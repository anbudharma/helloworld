$(function(){
	
	
	$(window).scroll(function() {
		$('.animation').each(function(){
			var animation = $(this).attr( 'rel' );
			var imagePos = $(this).offset().top;
		
			var topOfWindow = $(window).scrollTop();
			if (imagePos < topOfWindow+400) {
				$(this).addClass( animation );
			}
		});
	});
	$('.bxslider').bxSlider({
	  minSlides: 1,
	  maxSlides: 3,
	  slideWidth: 375,
	  slideMargin: 10,
	  ticker: false,
	  autoDirection: 'prev',
	  speed: 1500,
	});
	$('.bxslidersmall').bxSlider({
	  minSlides: 1,
	  maxSlides: 1,
	  slideWidth: 480,
	  slideMargin: 10,
	  ticker: false,
	  autoDirection: 'prev',
	  speed: 1500,
	});
	
	$('.bxslider1').bxSlider({
	slideWidth: 1400,
adaptiveHeight: true,
minSlides: 1,
maxSlides: 1,
moveSlides: 1,
slideMargin: 10,
 speed: 1500,
pager:false,
responsive:true,
auto: true,
autoControls: false,
controls:true
	});
});
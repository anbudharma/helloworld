$(function(){
	$('li.cat-item a').before('<i class="fa fa-angle-double-right"></i>');
	
      $('.artsliders').bxSlider({
    slideWidth: 263,
    minSlides: 3,
    maxSlides: 4,
    moveSlides: 1,
    slideMargin: 20,
	pager:false,
	responsive:true
  });
	});
	$(function(){
	 $('.welcome-holder .header-bottom-inner .woocommerce .instock a img').wrap( '<div class="product_box"></div>' );
	  $('.related ul li').removeClass('first').addClass('first1');
});
$(function(){
	
	$(".abouts ul li .actives").hover(function(){
    $(this)('.actives1').show();
},function(){
    $(this)('.actives1').hide();	
});

	
$('.bxslider_lg').bxSlider({
minSlides: 1,
maxSlides: 5,
moveSlides: 1,
slideMargin: 5,
slideWidth: 280,
pager:false,
responsive:true,
auto: true,
autoControls: true,
controls:true,
 speed: 800
 });
 
 $('.bxslider_xs').bxSlider({
minSlides: 1,
maxSlides: 1,
moveSlides: 1,
slideMargin: 5,
slideWidth: 280,
pager:false,
responsive:true,
auto: true,
autoControls: true,
controls:true,
 speed: 800
 });
 
  $('.bxslider_sm').bxSlider({
minSlides: 1,
maxSlides: 2,
moveSlides: 1,
slideMargin: 5,
slideWidth: 280,
pager:false,
responsive:true,
auto: true,
autoControls: true,
controls:true,
 speed: 800
 });
   $('.bxslider_md').bxSlider({
minSlides: 1,
maxSlides: 3,
moveSlides: 1,
slideMargin: 5,
slideWidth: 280,
pager:false,
responsive:true,
auto: true,
autoControls: true,
controls:true,
 speed: 800
 });
 

  $(".counter").countimator();

 
    $(window).scroll(function() {
        $('.animation').each(function(){
            var animation = $(this).attr( 'rel' );
            var imagePos = $(this).offset().top;
       
            var topOfWindow = $(window).scrollTop();
            if (imagePos < topOfWindow+400) {
                $(this).addClass( animation );
            }
        });
    });
	
	 fakewaffle.responsiveTabs(['xs', 'sm']);
	$('.gallery-icon a img').addClass('img-responsive');
});

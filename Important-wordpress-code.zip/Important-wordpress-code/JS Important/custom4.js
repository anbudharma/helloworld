$(function(){

	$('.make_purchase').click(function(){

	$('.paypal-pay-process').show();
	
	$.ajax({			url:'http://localhost/mala_new/wp-content/themes/mala/ajax.php',		
	data:$( '.wpsc_checkout_forms' ).serialize(),	
	type:'POST',		
	success:function(val){		
	$('.table-1').html('<tr><td><h4>'+val+'</h4></td></tr>');		
	$('.paypal-pay-process').hide();		
	}		
	});
	});	
	
	$('.wysija-paragraph input[type="text"]').addClass('form-control');	$('.wysija-paragraph input[type="email"]').addClass('form-control');	$('.wysija-submit').addClass('btn get_starts_bot');	$('.bottom-add-right-img img').addClass('img-responsive');	$('.bottom-add-left-img img').addClass('img-responsive');	$('.forms').hide();	$( ".search" ).click(function() {		$('.forms').toggle();	});	$('.artsliders').bxSlider({		slideWidth: 370,		minSlides: 1,		maxSlides: 3,		moveSlides: 1,		slideMargin: 20,		pager:false,		responsive:true	});	$('.validform').validate();});

function refreshCaptcha(){
	var img = document.images['captchaimg'];
	img.src = img.src.substring(0,img.src.lastIndexOf("?"))+"?rand="+Math.random()*1000;
}
	

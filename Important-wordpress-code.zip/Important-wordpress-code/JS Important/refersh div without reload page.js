$(function(){
    setInterval(function() {
         myTimer();
    }, 1000);
});
function myTimer(){
	$.ajax({
		type : 'POST',
		url : 'http://localhost/merdian/timer/',
		data : '',
		success : function(data){
			$('.dynamic-timer').html(data);
		}
	});
}// JavaScript Document


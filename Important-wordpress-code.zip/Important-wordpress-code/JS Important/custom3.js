$(function(){	
	var modal = readCookie("autoMyModal");
	
	if( modal != "True" ){
		createCookie("autoMyModal", "True", 1);
		$('#autoMyModal').modal('show');
	}
	
	$('.bxslider_mobile').bxSlider({
         minSlides: 1,
         maxSlides: 1,
         slideWidth: 370,
         slideMargin: 0,
         ticker: false,
         speed: 1000,
         pager:false,
         controls:true
       })
	   $('.bxslider_sm').bxSlider({
         minSlides: 1,
         maxSlides: 3,
         slideWidth: 250,
         slideMargin: 0,
         ticker: false,
         speed: 1000,
         pager:false,
         controls:true
       })
	   $('.bxslider_xs').bxSlider({
         minSlides: 1,
         maxSlides: 1,
         slideWidth: 370,
         slideMargin: 0,
         ticker: false,
         speed: 1000,
         pager:false,
         controls:true
       })
	    $('.bxslider_md').bxSlider({
         minSlides: 1,
         maxSlides: 3,
         slideWidth: 300,
         slideMargin: 0,
         ticker: false,
         speed: 1000,
         pager:false,
         controls:true
       })
	   
	$('.bxslider_desktop').bxSlider({
		slideWidth: 300,
		adaptiveHeight: true,
		minSlides: 1,
		maxSlides: 4,
		moveSlides: 1,
		slideMargin: 0,
		pager:false,
		responsive:true,
		auto: true,
		 speed: 1000,
		autoControls: false,
		controls:true
	 })
	 
	  $('.bxslider_clients').bxSlider({
         minSlides: 1,
         maxSlides: 5,
         slideWidth: 200,
		 adaptiveHeight: true,
		 moveSlides: 1,
         slideMargin: 0,
         ticker: false,
         speed: 1000,
         pager:false,
		 auto: true,
         controls:false
       })
  
  $('#stwrapper').append('<a href="#" class="share-close-btn">Close Button</a>');
  
	});
	
function createCookie(name, value, days) {
	var expires;	
	if (days) {
		var date = new Date();
		date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
		expires = "; expires=" + date.toGMTString();
	} else {
		expires = "";
	}
	document.cookie = escape(name) + "=" + escape(value) + expires + "; path=/";
}

function readCookie(name) {
	var nameEQ = escape(name) + "=";
	var ca = document.cookie.split(';');
	for (var i = 0; i < ca.length; i++) {
		var c = ca[i];
		while (c.charAt(0) === ' ') c = c.substring(1, c.length);
		if (c.indexOf(nameEQ) === 0) return unescape(c.substring(nameEQ.length, c.length));
	}
	return null;
}

function eraseCookie(name) {
	createCookie(name, "", -1);
}
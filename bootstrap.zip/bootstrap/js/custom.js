$(function() {

		
	$('.owl-carousel').owlCarousel({
		loop:true,
		lazyLoad:true,
		margin:1,
		autoplay:true,
		autoplayTimeout:5000,
		autoplaySpeed:3000,
		touchDrag  : true,
		mouseDrag  : true,
		dots: false,
		responsiveClass:true,
		responsive:{
			1366:{
				items:1,
				nav:true
			},
			1024:{
				items:1,
				nav:true
			},
			640:{
				items:1,
				nav:true
			},
			0:{
				items:1,
				nav:true
			}
		}
	})
		$('.owl-carousel-2').owlCarousel({
		loop:true,
		lazyLoad:true,
		margin:20,
		autoplay:true,
		autoplayTimeout:5000,
		autoplaySpeed:3000,
		touchDrag  : true,
		mouseDrag  : true,
		dots: false,
		responsiveClass:true,
		responsive:{
			1366:{
				items:2,
				nav:true
			},
			1024:{
				items:2,
				nav:true
			},
			640:{
				items:1,
				nav:true
			},
			0:{
				items:1,
				nav:true
			}
		}
	})
		$('.owl-carousel-1').owlCarousel({
		loop:true,
		lazyLoad:true,
		margin:1,
		autoplay:true,
		autoplayTimeout:5000,
		autoplaySpeed:3000,
		touchDrag  : true,
		mouseDrag  : true,
		dots: false,
		responsiveClass:true,
		responsive:{
			1366:{
				items:1,
				nav:true
			},
			1024:{
				items:1,
				nav:true
			},
			640:{
				items:1,
				nav:true
			},
			0:{
				items:1,
				nav:true
			}
		}
	})

});